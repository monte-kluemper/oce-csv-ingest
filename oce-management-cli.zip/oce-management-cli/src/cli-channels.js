#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).channels
    }

    program.version('2020.03.05')
    program
      .command('listChannels')
      .description('List All Channels')
      .option(
        '--roleName <value>',
        'This parameter is used to filter the returned channels with the given role name. This parameter is optional in the query and by default all the channels are returned.'
      )
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>roleName</b></i>, <i><b>repositoryId</b></i> and <i><b>name</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on the others. This query param is optional and defaults to <i><b>roleName eq "viewer"</b></i> which filters the resources with at least given role. <i><b>name</b></i> is interpreted in the context of the resource being requested. For eg. name for content types implies content type name.<br><b>Example</b>:<br> ?q=roleName eq "manager")'
      )
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields in each channel in the list. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each channel in the list. All the field names are case-sensitive, and users must provide the correct field names in the query. Each channel has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>, <i>isSiteChannel</i>) and additional fields (<i>channelType</i>, <i>publishPolicy</i>, <i>localizationPolicy</i>, <i>channelTokens</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. The user can filter out only the additional fields. This parameter is optional in the query, and by default the result shows only standard fields in the response. Any incorrect or invalid field name given in the query will throw an error. <br><br> <b>Example</b>: <i>?fields=channelTokens,localizationPolicy</i> <br> This returns all standard fields along with the <i>channelTokens</i> and <i>localizationPolicy</i> additional fields for each channel.<br> <b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each channel. <br> '
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--orderBy <value>',
        'This parameter is used to control the order of results. The value of this query parameter follows the format of <i> fieldName:[asc/desc]</i>. <i>asc</i> stands for ascending order  <i>desc</i> stands for descending order, default order is <i>asc</i>. The only field names allowed are <b>name</b> and <b>updatedDate</b>.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const roleName = cmd.roleName
        const q = cmd.q
        const fields = cmd.fields
        const offset = cmd.offset
        const limit = cmd.limit
        const orderBy = cmd.orderBy
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .listChannels({
            roleName,
            q,
            fields,
            offset,
            limit,
            orderBy,
            totalResults,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('createChannel')
      .description('Create a Channel')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createChannel({ body, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getChannel')
      .description('Read a Channel')
      .requiredOption('--id <value>', 'id of the channel.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getChannel({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('updateChannel')
      .description('Update a Channel')
      .requiredOption('--id <value>', 'id of the channel.')
      .option('--refreshTokens <value>', 'Refresh Token')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const refreshTokens = cmd.refreshTokens
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .updateChannel({
            id,
            body,
            refreshTokens,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('deleteChannel')
      .description('Delete a Channel')
      .requiredOption('--id <value>', 'id of the channel.')
      .action(async cmd => {
        const id = cmd.id

        const op = await getOp()

        return op
          .deleteChannel({ id, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listChannelPermissions')
      .description('List All Permissions on a Channel')
      .requiredOption('--id <value>', 'id of the channel.')
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .listChannelPermissions({ id, offset, limit, totalResults, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
