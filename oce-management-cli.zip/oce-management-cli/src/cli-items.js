#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).items
    }

    program.version('2020.03.05')
    program
      .command('createItem')
      .description('Create an Item')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createItem({ body, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItem')
      .description('Read an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--expand <value>',
        'Expand parameter provides the option of getting child resources (referenced items) inline with the item\'s response. Accepts a comma-separated list of field names or <i>all</i>. All the user-defined field names should be provided with prefix <i>fields</i> and followed by a period (.). If these fields are of a reference type, then the resource expands their data inline in the response. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the reference type of the requested item are expanded. When expand is not specified, item response contains links to the referenced items. Expansion of this form is supported for one level only; a request to expand beyond the first level of referenced fields will produce the response HTTP 400. When the expand parameter contains a nonexistent field as per type definition of the requested item, the resource produces HTTP 400.<br><br><b>Example</b> : expand=<i>fields.field1,fields.field2</i> <br>Returns field1 and field2: names of the user-defined fields in the type to which this item belongs.<br><b>Example</b> : expand=<i>taxonomies</i> <br>Returns taxonomies field containing all categories assigned to this item.<br><b>Example</b> : expand=<i>all</i> <br>Returns all fields available for this item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .option(
        '--asOf <value>',
        'This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version.'
      )
      .option(
        '--asOfDate <value>',
        'This parameter defines a point of time as of which the item revision should be returned. The date string format is <i>yyyy-MM-dd\'T\'HH:mm:ss\'Z\'</i> or <i>yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'</i>.'
      )
      .action(async cmd => {
        const id = cmd.id
        const expand = cmd.expand
        const links = cmd.links
        const asOf = cmd.asOf
        const asOfDate = cmd.asOfDate

        const op = await getOp()

        return op
          .getItem({ id, expand, links, asOf, asOfDate })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('updateItem')
      .description('Update an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .updateItem({ body, id, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('deleteItem')
      .description('Delete an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .action(async cmd => {
        const id = cmd.id

        const op = await getOp()

        return op
          .deleteItem({ id, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemChannels')
      .description('List Channels of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemChannels({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemCollections')
      .description('List Collections of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemCollections({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemPublishInfo')
      .description('Read Publish Info of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemPublishInfo({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemPublishedChannels')
      .description('List Published Channels of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemPublishedChannels({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemsRelationships')
      .description('List Relationships of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemsRelationships({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemTags')
      .description('List Tags of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemTags({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemTaxonomies')
      .description('List all Taxonomies and Categories of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemTaxonomies({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('lisItemVariations')
      .description('List Variations of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .lisItemVariations({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemVersionInfo')
      .description('Read Version Info of an Item')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemVersionInfo({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listTimeZones')
      .description('List All Time Zones')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links

        const op = await getOp()

        return op
          .listTimeZones({ links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
