#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).itemRevisions
    }

    program.version('2020.03.05')
    program
      .command('getItemRevisionsBySlug')
      .description('List item revisions by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemRevisionsBySlug({ slug, offset, limit, totalResults, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemRevisionBySlug')
      .description('Read an item revision by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .requiredOption('--version <value>', 'The version of an item revision')
      .option(
        '--expand <value>',
        'Expand parameter provides the option of getting child resources (referenced items) inline with the item\'s response. Accepts a comma-separated list of field names or <i>all</i>. All the user-defined field names should be provided with prefix <i>fields</i> and followed by a period (.). If these fields are of a reference type, then the resource expands their data inline in the response. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the reference type of the requested item are expanded. When expand is not specified, item response contains links to the referenced items. Expansion of this form is supported for one level only; a request to expand beyond the first level of referenced fields will produce the response HTTP 400. When the expand parameter contains a nonexistent field as per type definition of the requested item, the resource produces HTTP 400.<br>Examples : </br><ol>expand=<i>fields.field1,fields.field2</i></ol><ol>expand=<i>all</i></ol> where field1, field2 are names of the user-defined fields in the type to which this item belongs.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const version = cmd.version
        const expand = cmd.expand
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemRevisionBySlug({ slug, version, expand, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemRevisions')
      .description('List item revisions')
      .requiredOption('--guid <value>', 'id of the item.')
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const guid = cmd.guid
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemRevisions({ guid, offset, limit, totalResults, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemRevision')
      .description('Read an item revision')
      .requiredOption('--guid <value>', 'id of the item.')
      .requiredOption('--version <value>', 'The version of an item revision')
      .option(
        '--expand <value>',
        'Expand parameter provides the option of getting child resources (referenced items) inline with the item\'s response. Accepts a comma-separated list of field names or <i>all</i>. All the user-defined field names should be provided with prefix <i>fields</i> and followed by a period (.). If these fields are of a reference type, then the resource expands their data inline in the response. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the reference type of the requested item are expanded. When expand is not specified, item response contains links to the referenced items. Expansion of this form is supported for one level only; a request to expand beyond the first level of referenced fields will produce the response HTTP 400. When the expand parameter contains a nonexistent field as per type definition of the requested item, the resource produces HTTP 400.<br>Examples : </br><ol>expand=<i>fields.field1,fields.field2</i></ol><ol>expand=<i>all</i></ol> where field1, field2 are names of the user-defined fields in the type to which this item belongs.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const guid = cmd.guid
        const version = cmd.version
        const expand = cmd.expand
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemRevision({ guid, version, expand, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
