#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).recommendations
    }

    program.version('2020.03.05')
    program
      .command('getAudienceAttributes')
      .description('List all Audience Attributes.')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>name</i> and <i>categoryId</i> The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/properties?q=(categoryId eq "AWVF3H79KJ2312VB0")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/properties?q=(name eq "Some property")'
      )
      .option('--default <value>', 'Default search query expression.')
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a audience attribute. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each property in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each audience attribute has both standard fields (<i>id</i>, <i>name</i>, <i>description</i> and <i>categoryId</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each audience attribute. <br> '
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option('--orderBy <value>', 'Order by results.')
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const q = cmd.q
        const _default = cmd.default
        const fields = cmd.fields
        const offset = cmd.offset
        const limit = cmd.limit
        const orderBy = cmd.orderBy
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .getAudienceAttributes({
            q,
            _default,
            fields,
            offset,
            limit,
            orderBy,
            totalResults,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('createAudienceAttribute')
      .description('Create an Audience Attributes.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createAudienceAttribute({
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getAudienceAttribute')
      .description('Read a specific audience attributes by id.')
      .requiredOption('--id <value>', 'Id of the audience attributes.')
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a audience attribute. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each property in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each audience attribute has both standard fields (<i>id</i>, <i>name</i>, <i>description</i> and <i>categoryId</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each audience attribute. <br> '
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const fields = cmd.fields
        const links = cmd.links

        const op = await getOp()

        return op
          .getAudienceAttribute({ id, fields, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('updateAudienceAttribute')
      .description('Update an Audience Attribute.')
      .requiredOption('--id <value>', 'Id of the audience attributes.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .updateAudienceAttribute({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('deleteAudienceAttributeById')
      .description('Delete an audience attribute by id.')
      .requiredOption('--id <value>', 'Id of the audience attributes.')
      .action(async cmd => {
        const id = cmd.id

        const op = await getOp()

        return op
          .deleteAudienceAttributeById({ id, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getCategories')
      .description(
        'This resource returns a list of available attribute categories.'
      )
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>name</i> and <i>type</i>When listing categories, <i>type</i> can be equal to "standard", "custom" or "all". If <i>type</i> is equals to "all", all categories will be retrieved. The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/categories?q=(type eq "custom")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/categories?q=(name eq "Some space")'
      )
      .option('--default <value>', 'Default search query expression.')
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a attribute category. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each category in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each recommendation has both standard fields (<i>id</i>, <i>name</i>, <i>description</i> and <i>type</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each category. <br> '
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option('--orderBy <value>', 'Order by results.')
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const q = cmd.q
        const _default = cmd.default
        const fields = cmd.fields
        const offset = cmd.offset
        const limit = cmd.limit
        const orderBy = cmd.orderBy
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .getCategories({
            q,
            _default,
            fields,
            offset,
            limit,
            orderBy,
            totalResults,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getCategory')
      .description('Read a specific category by id.')
      .requiredOption('--id <value>', 'Id of the category.')
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a attribute category. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each category in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each recommendation has both standard fields (<i>id</i>, <i>name</i>, <i>description</i> and <i>type</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each category. <br> '
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const fields = cmd.fields
        const links = cmd.links

        const op = await getOp()

        return op
          .getCategory({ id, fields, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('testRecommendation')
      .description('Obtain the results from the recommendation.')
      .requiredOption('--apiName <value>', 'API name of the recommendation.')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field name allowed is <i>repositoryId</i>. The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(apiName eq "TestRecommendation")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(repositoryId eq "EAQWER42DGKJ10PCNMGAE")'
      )
      .option(
        '--attributeCategoryAttributeName <value>',
        `List of audience attributes. The audience attributes should be prefixed with the keyword <b>attribute</b>: <br/><br/><b><i>attribute.\<category\>.\<audienceAttribute\>=\<value\></i></b><br/><br/><b>Example:</b>  <i>?attribute.custom.myAttribute1=value1&attribute.custom.myAttribute2=value2</i><br/><br/><br/><br/>Where multivalued audience attributes are allowed, they can be provided in the query by repeating the name value pairs. <br/><br/><b>Example:</b>  <i>?attribute.custom.myMultiValue=value1&attribute.custom.myMultiValue=value2</i> etc.<br/><br/>
`
      )
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields in each item in the result. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each items in the result. All the field name are case-sensitive, and users must provide the correct field name in the query. All the user-defined field names should be provided with prefix fields and followed by period (.). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard fields are returned in case of query across types and in case of type specific query, all standard and user fields are returned. This parameter is optional in the query, and by default the result shows only standard fields name, description. The standard fields <i>id</i>, <i>type</i> are always returned irrespective of any field asked. Any incorrect or invalid field name given in the query will throw an error.<br><br><b>Example</b>: This returns standard fields <i>name</i>, user fields <i>state</i> and <i>country</i> of type <i>Address</i> in the search results. <br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=fields.state,fields.country <br><br><b>Example</b>: This returns all the attributes for a specific type used in the search results.<br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=all<br><br><b>Example</b>: This returns standard fields <i>name</i>, <i>createdBy</i> in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=name,createdBy<br><br><b>Example</b>: This returns all the standard fields in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=all'
      )
      .option(
        '--channelToken <value>',
        'Channel token to use to test the recommendation against. If no channel is provided, the recommendation will run against all assets in the current repository and not only assets published to or targeted for a specific channel.'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const apiName = cmd.apiName
        const q = cmd.q
        const attributeCategoryAttributeName =
          cmd.attributeCategoryAttributeName
        const fields = cmd.fields
        const channelToken = cmd.channelToken
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .testRecommendation({
            apiName,
            q,
            body,
            attributeCategoryAttributeName,
            fields,
            channelToken,
            offset,
            limit,
            totalResults,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getRecommendations')
      .description('List all recommendations')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field name allowed is <i>repositoryId</i>. The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(apiName eq "TestRecommendation")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(repositoryId eq "EAQWER42DGKJ10PCNMGAE")'
      )
      .option('--default <value>', 'Default search query expression.')
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a recommendation. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each recommendation in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each recommendation has both standard fields (<i>id</i>, <i>name</i>, <i>apiName</i>, <i>description</i>, <i>createdBy</i>, <i>createdAt</i>, <i>updatedBy</i>, <i>updatedAt</i>, <i>main</i> and <i>defaults</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each recommendation. <br> '
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--orderBy <value>',
        'Order by results. Recommendations can currently only be ordered by name.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const q = cmd.q
        const _default = cmd.default
        const fields = cmd.fields
        const offset = cmd.offset
        const limit = cmd.limit
        const orderBy = cmd.orderBy
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .getRecommendations({
            q,
            _default,
            fields,
            offset,
            limit,
            orderBy,
            totalResults,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('createRecommendation')
      .description('Create a new Recommendation.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createRecommendation({
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getRecommendation')
      .description('Read a specific Recommendation by id.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field name allowed is <i>repositoryId</i>. The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(apiName eq "TestRecommendation")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(repositoryId eq "EAQWER42DGKJ10PCNMGAE")'
      )
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a recommendation. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each recommendation in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each recommendation has both standard fields (<i>id</i>, <i>name</i>, <i>apiName</i>, <i>description</i>, <i>createdBy</i>, <i>createdAt</i>, <i>updatedBy</i>, <i>updatedAt</i>, <i>main</i> and <i>defaults</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each recommendation. <br> '
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const q = cmd.q
        const fields = cmd.fields
        const links = cmd.links

        const op = await getOp()

        return op
          .getRecommendation({ id, q, fields, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('updateRecommendation')
      .description('Update a Recommendation.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .updateRecommendation({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('deleteRecommendationById')
      .description('Delete a Recommendation.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .action(async cmd => {
        const id = cmd.id

        const op = await getOp()

        return op
          .deleteRecommendationById({ id, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('approveRecommendation')
      .description('Approve or reject a recommendation.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .approveRecommendation({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('publishRecommendation')
      .description('Publish a Recommendation.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .publishRecommendation({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getPublishJobStatus')
      .description('Read publish job status.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .requiredOption(
        '--statusId <value>',
        'Status id of the Recommendation publish operation.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const statusId = cmd.statusId
        const links = cmd.links

        const op = await getOp()

        return op
          .getPublishJobStatus({ id, statusId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getRecommendationPublishJobItemIds')
      .description("Read the Recommendation's published Item ids")
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .requiredOption(
        '--statusId <value>',
        'Status id of the Recommendation publish operation.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .action(async cmd => {
        const id = cmd.id
        const statusId = cmd.statusId
        const links = cmd.links
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults

        const op = await getOp()

        return op
          .getRecommendationPublishJobItemIds({
            id,
            statusId,
            links,
            offset,
            limit,
            totalResults
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('submitRecommendation')
      .description('Submit a recommendation for approval.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .submitRecommendation({ id, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('unpublishRecommendation')
      .description('Unpublish a Recommendation.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .unpublishRecommendation({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getUnpublishJobStatus')
      .description('Read unpublish job status.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .requiredOption(
        '--statusId <value>',
        'Status id of the Recommendation publish operation.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const statusId = cmd.statusId
        const links = cmd.links

        const op = await getOp()

        return op
          .getUnpublishJobStatus({ id, statusId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getRecommendationUnpublishJobItemIds')
      .description("Read the Recommendation's unpublished Item ids")
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .requiredOption(
        '--statusId <value>',
        'Status id of the Recommendation publish operation.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .action(async cmd => {
        const id = cmd.id
        const statusId = cmd.statusId
        const links = cmd.links
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults

        const op = await getOp()

        return op
          .getRecommendationUnpublishJobItemIds({
            id,
            statusId,
            links,
            offset,
            limit,
            totalResults
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('validateRecommendation')
      .description('Validate a recommendation.')
      .requiredOption('--id <value>', 'Id of the Recommendation.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .validateRecommendation({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
