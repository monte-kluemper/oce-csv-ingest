#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).localizationPolicies
    }

    program.version('2020.03.05')
    program
      .command('listLocalizationPolicies')
      .description('List All Localization Policies')
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--orderBy <value>',
        'This parameter is used to control order of results. The value of this query parameter follow the format of <i> fieldName:[asc/desc]</i>. <i>asc</i> stands for ascending order  <i>desc</i> stands for descending order, default order is <i>asc</i>. The only fields allowed in the field name are <b>name</b> and <b>updatedDate</b>.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>name</b></i> and <i><b>connectorType</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on <i><b>connectorType</b></i>. This query param is optional with no default.<br><b>Example</b>:<br> ?q=name co "foo")<br><b>Example</b>:<br> ?q=connectorType eq "translation")<br><b>Example</b>:<br> ?q=connectorType eq "content")'
      )
      .action(async cmd => {
        const offset = cmd.offset
        const limit = cmd.limit
        const orderBy = cmd.orderBy
        const totalResults = cmd.totalResults
        const links = cmd.links
        const q = cmd.q

        const op = await getOp()

        return op
          .listLocalizationPolicies({
            offset,
            limit,
            orderBy,
            totalResults,
            links,
            q
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('createLocalizationPolicy')
      .description('Create a Localization Policy')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createLocalizationPolicy({
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getPolicy')
      .description('Read a Localization Policy')
      .requiredOption('--id <value>', 'Localization Policy id')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getPolicy({ id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('updatePolicy')
      .description('Update a Localization Policy')
      .requiredOption('--id <value>', 'Localization Policy id')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .updatePolicy({ id, body, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('deletePolicy')
      .description('Delete a Localization Policy')
      .requiredOption('--id <value>', 'Localization Policy id')
      .action(async cmd => {
        const id = cmd.id

        const op = await getOp()

        return op
          .deletePolicy({ id, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
