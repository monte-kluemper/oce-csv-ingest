#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).taxonomies
    }

    program.version('2020.03.05')
    program
      .command('getTaxonomies')
      .description('List taxonomies')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>status</i> and <i>version</i>. A query cannot include multiple <i>status</i> or <i>version</i> fieldNames. If no value is provided for <i>status</i> it defaults to "promoted". When listing taxonomies, <i>status</i> can be equals to "draft", "promoted" or "all". If <i>status</i> is equals to "all", all taxonomies will be retrieved - if a taxonomy is currently available in both "draft" and "promoted" states, only "draft" will be returned. In case <i>status</i> equals to "all" is used in other endpoints, an error will be returned. The field <i>version</i> is currently ignored.   The only value allowed in the operator is <i>eq</i> (Equals).<br><br>When updating a taxonomy the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted taxonomy cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "promoted")'
      )
      .option('--default <value>', 'Default search query expression.')
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a taxonomy. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each taxonomy in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each taxonomy has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>shortName</i>, <i>status</i>, <i>version</i>, <i>isPublishable</i>, <i>customProperties</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>) and additional fields (<i>availableStates</i> and <i>publishedChannels</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Taxonomy in "draft" state will not have a <i>version</i>. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in error. <br><br> This returns all standard fields along with the additional field <i>availableStates</i> for each taxonomy.<br><b>Example</b>: <i>?fields=availableStates</i> <br><br> This returns all standard fields along with the additional fields <i>availableStates</i> and <i>publishedChannels</i> for each taxonomy.<br><b>Example</b>: <i>?fields=availableStates,publishedChannels</i> <br><br> This returns all standard fields along with all additional fields (<i>availableStates</i> and <i>publishedChannels</i>) for each taxonomy.<br> <b>Example</b>: <i>?fields=all</i> <br> '
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option('--orderBy <value>', 'Order by results.')
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const q = cmd.q
        const _default = cmd.default
        const fields = cmd.fields
        const offset = cmd.offset
        const limit = cmd.limit
        const orderBy = cmd.orderBy
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .getTaxonomies({
            q,
            _default,
            fields,
            offset,
            limit,
            orderBy,
            totalResults,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('createTaxonomy')
      .description('Create a taxonomy')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createTaxonomy({ body, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getTaxonomy')
      .description('Read a taxonomy')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>status</i> and <i>version</i>. A query cannot include multiple <i>status</i> or <i>version</i> fieldNames. If no value is provided for <i>status</i> it defaults to "promoted". When listing taxonomies, <i>status</i> can be equals to "draft", "promoted" or "all". If <i>status</i> is equals to "all", all taxonomies will be retrieved - if a taxonomy is currently available in both "draft" and "promoted" states, only "draft" will be returned. In case <i>status</i> equals to "all" is used in other endpoints, an error will be returned. The field <i>version</i> is currently ignored.   The only value allowed in the operator is <i>eq</i> (Equals).<br><br>When updating a taxonomy the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted taxonomy cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "promoted")'
      )
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a taxonomy. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each taxonomy in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each taxonomy has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>shortName</i>, <i>status</i>, <i>version</i>, <i>isPublishable</i>, <i>customProperties</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>) and additional fields (<i>availableStates</i> and <i>publishedChannels</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Taxonomy in "draft" state will not have a <i>version</i>. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in error. <br><br> This returns all standard fields along with the additional field <i>availableStates</i> for each taxonomy.<br><b>Example</b>: <i>?fields=availableStates</i> <br><br> This returns all standard fields along with the additional fields <i>availableStates</i> and <i>publishedChannels</i> for each taxonomy.<br><b>Example</b>: <i>?fields=availableStates,publishedChannels</i> <br><br> This returns all standard fields along with all additional fields (<i>availableStates</i> and <i>publishedChannels</i>) for each taxonomy.<br> <b>Example</b>: <i>?fields=all</i> <br> '
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const q = cmd.q
        const fields = cmd.fields
        const links = cmd.links

        const op = await getOp()

        return op
          .getTaxonomy({ id, q, fields, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('updateTaxonomy')
      .description('Update a taxonomy')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>status</i> and <i>version</i>. A query cannot include multiple <i>status</i> or <i>version</i> fieldNames. If no value is provided for <i>status</i> it defaults to "promoted". When listing taxonomies, <i>status</i> can be equals to "draft", "promoted" or "all". If <i>status</i> is equals to "all", all taxonomies will be retrieved - if a taxonomy is currently available in both "draft" and "promoted" states, only "draft" will be returned. In case <i>status</i> equals to "all" is used in other endpoints, an error will be returned. The field <i>version</i> is currently ignored.   The only value allowed in the operator is <i>eq</i> (Equals).<br><br>When updating a taxonomy the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted taxonomy cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "promoted")'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const q = cmd.q
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .updateTaxonomy({
            id,
            q,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('deleteTaxonomyById')
      .description('Delete a taxonomy')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>status</i> and <i>version</i>. A query cannot include multiple <i>status</i> or <i>version</i> fieldNames. If no value is provided for <i>status</i> it defaults to "promoted". When listing taxonomies, <i>status</i> can be equals to "draft", "promoted" or "all". If <i>status</i> is equals to "all", all taxonomies will be retrieved - if a taxonomy is currently available in both "draft" and "promoted" states, only "draft" will be returned. In case <i>status</i> equals to "all" is used in other endpoints, an error will be returned. The field <i>version</i> is currently ignored.   The only value allowed in the operator is <i>eq</i> (Equals).<br><br>When updating a taxonomy the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted taxonomy cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "promoted")'
      )
      .action(async cmd => {
        const id = cmd.id
        const q = cmd.q

        const op = await getOp()

        return op
          .deleteTaxonomyById({ id, q, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getCategories_1')
      .description('Search categories')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Many query conditions can be joined using AND/OR operators and grouped with parentheses. The value of the query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i><br/><br/>The only field names supported are <i>status</i>, <i>parent.id</i>, <i>parentId</i>, <i>id</i>, <i>name</i>, and <i>apiName</i>. If no value is provided for <i>status</i> it defaults to "promoted".  The field <i>parentId</td> is a legacy field from the database search and is interchangeable with <i>parent.id</i>.<br><br>When a <i>parentId</i> or <i>parent.id</i> is provided, only categories with that parent id will be listed.  If no <i>parentId</i> is provided, categories from all levels will be returned in the list.<br><br>When a <i>id</i> is provided, categories matching the criteria with be returned.  The valid operator is <i>eq</i>.<br><br>When a <i>name</i> is provided, categories matching the criteria with be returned.  The valid operators are <i>eq</i>, <i>sw</i>, and <i>co</i>.<br><br>When an <i>apiName</i> is provided, categories matching the criteria with be returned.  The valid operator is <i>eq</i>.<br><br>When updating a category the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted category cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted" and parent.id eq "DJGSAFWEGSSADWDFEWG235F")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted" and id eq "DJGSAFWEGSSADWDFEWG235F")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted" and name sw "car")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted" and apiName eq "AAAA")'
      )
      .option(
        '--fields <value>',
        'The fields parameter is used to control the returned fields and values in the queried category. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each queried category. As all the field names are case-sensitive, users must provide the correct field names in the search query. When fields is specified as <i>all</i> (in lower case), all the standard fields and optional fields are returned for each category. Each category has both standard fields (<i>id</i>, <i>name</i>, <i>apiName</i>, <i>description</i>, <i>parent</i>, <i>parentId</i>, <i>position</i>, <i>status</i>) and optional fields (<i>ancestors</i>). The standard field <i>id</i> is always returned in the response and cannot be filtered out. This parameter is optional in the query and by default query result shows only <i>id</i>, <i>name</i>, <i>description</i>, <i>apiName</i>, <i>status</i>, <i>position</i>, <i>parentId</i> in the response. Any incorrect or invalid field name given will result in an error. <br><br> <b>Example</b>: <i>?q=(name co "car")&fields=name,description,parent,ancestors</i> <br> This returns <i>id</i>, <i>name</i>, <i>description</i>, <i>parent</i> and <i>ancestors</i> in the search results for a category containing "car" in the <i>name</i> field. <br> <b>Example</b>: <i>?fields=name,parent</i> <br> This will return only standard fields (such as <i>id</i>, <i>name</i> and <i>parent</i>) for all categories within the default limit. <br>'
      )
      .option('--default <value>', 'Default search query expression.')
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--orderBy <value>',
        'This parameter is used to control order of results. The value of this query parameter follow the format of fieldName:[asc/desc]. asc stands for ascending order desc stands for descending order. <br/><br/>Allowed fields are <i>name</i> and <i>position</i>. The default sort order is <i>asc</i>.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const q = cmd.q
        const fields = cmd.fields
        const _default = cmd.default
        const offset = cmd.offset
        const limit = cmd.limit
        const orderBy = cmd.orderBy
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .getCategories_1({
            id,
            q,
            fields,
            _default,
            offset,
            limit,
            orderBy,
            totalResults,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('createCategory')
      .description('Create a category')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createCategory({ id, body, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getCategory_1')
      .description('Read a category')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption(
        '--categoryId <value>',
        'Unique identifier (id) for a category.'
      )
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Many query conditions can be joined using AND/OR operators and grouped with parentheses. The value of the query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names supported are <i>status</i> and <i>version</i>. If no value is provided for <i>status</i> it defaults to "promoted". The field <i>version</i> is currently ignored.  The only value allowed in the operator is <i>eq</i> (Equals).  <br><br>When updating a category the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted category cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted")'
      )
      .option('--default <value>', 'Default search query expression.')
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields for a category. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each category in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each category has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>position</i>, <i>parentId</i>) and additional fields (<i>namePath</i>, <i>idPath</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default results shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=namePath</i> <br> This returns all standard fields along with the <i>namedPath</i> additional field for the category.<br> <b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for the category. <br> '
      )
      .option(
        '--expand <value>',
        'Expand parameter provides the option of getting child resources (referenced items) inline with the category\'s response. Accepts a comma-separated list of field names or <i>all</i>. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the requested category are expanded. When expand is not specified, the category response contains links to the referenced children. Expansion of this form is supported for one level only. When the expand parameter contains a nonexistent field as per category definition, the resource produces HTTP 400.<br><br><b>Example</b> : expand=<i>children</i> <br>Returns children categories sorted by their respective <i>position</i> ascending. This sort order cannot be changed in this request.<br><b>Example</b> : expand=<i>all</i> <br>Returns child resources (<i>children</i>) available for this category. Only the first 1000 children categories will be expanded.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const categoryId = cmd.categoryId
        const q = cmd.q
        const _default = cmd.default
        const fields = cmd.fields
        const expand = cmd.expand
        const links = cmd.links

        const op = await getOp()

        return op
          .getCategory_1({ id, categoryId, q, _default, fields, expand, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('updateCategory')
      .description('Update a category')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption(
        '--categoryId <value>',
        'Unique identifier (id) for a category.'
      )
      .option('--q <value>', 'Query expression.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const categoryId = cmd.categoryId
        const q = cmd.q
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .updateCategory({
            id,
            categoryId,
            q,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('deleteCategory')
      .description('Delete a category')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption(
        '--categoryId <value>',
        'Unique identifier (id) for a category.'
      )
      .option('--q <value>', 'Query expression.')
      .action(async cmd => {
        const id = cmd.id
        const categoryId = cmd.categoryId
        const q = cmd.q

        const op = await getOp()

        return op
          .deleteCategory({
            id,
            categoryId,
            q,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('copyCategory')
      .description('Copy a category')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption(
        '--categoryId <value>',
        'Unique identifier (id) for a category.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const categoryId = cmd.categoryId
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .copyCategory({
            id,
            categoryId,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getCopyCategoryJobStatus')
      .description('Read copy category status')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption(
        '--categoryId <value>',
        'Unique identifier (id) for a category.'
      )
      .requiredOption('--jobTokenId <value>', 'id for the job.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const categoryId = cmd.categoryId
        const jobTokenId = cmd.jobTokenId
        const links = cmd.links

        const op = await getOp()

        return op
          .getCopyCategoryJobStatus({ id, categoryId, jobTokenId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('createDraftTaxonomy')
      .description('Create a new draft version')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createDraftTaxonomy({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getCreateDraftJobStatus')
      .description('Read draft creation status')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption('--jobTokenId <value>', 'id for the job.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const jobTokenId = cmd.jobTokenId
        const links = cmd.links

        const op = await getOp()

        return op
          .getCreateDraftJobStatus({ id, jobTokenId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('promoteTaxonomy')
      .description('Promote a taxonomy')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .promoteTaxonomy({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getPromoteJobStatus')
      .description('Read promote status')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption('--jobTokenId <value>', 'id for the job.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const jobTokenId = cmd.jobTokenId
        const links = cmd.links

        const op = await getOp()

        return op
          .getPromoteJobStatus({ id, jobTokenId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('publishTaxonomy')
      .description('Publish a taxonomy')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .publishTaxonomy({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getPublishJobStatus_1')
      .description('Read publish job status')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption('--jobTokenId <value>', 'id for the job.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const jobTokenId = cmd.jobTokenId
        const links = cmd.links

        const op = await getOp()

        return op
          .getPublishJobStatus_1({ id, jobTokenId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('unpublishTaxonomy')
      .description('Unpublish a taxonomy')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .unpublishTaxonomy({
            id,
            body,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getUnpublishJobStatus_1')
      .description('Read unpublish status')
      .requiredOption('--id <value>', 'id of the taxonomy.')
      .requiredOption('--jobTokenId <value>', 'id for the job.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const id = cmd.id
        const jobTokenId = cmd.jobTokenId
        const links = cmd.links

        const op = await getOp()

        return op
          .getUnpublishJobStatus_1({ id, jobTokenId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
