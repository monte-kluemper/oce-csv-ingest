#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).permissionOperations
    }

    program.version('2020.03.05')
    program
      .command('executePermissionOperations')
      .description('Performs Permission Operations on resource')
      .option(
        '--prefer <value>',
        'This parameter is used to control the interaction type (synchronous/asynchronous) of the request. If the header is provided with value respond-async, it indicates that asynchronous interaction is preferred. Otherwise, synchronous interaction is preferred. Asynchronous request is responded with 202 status with a status link in the location header. Synchronous request is responded with 200 along with response body.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const prefer = cmd.prefer
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .executePermissionOperations({
            body,
            prefer,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getPermissionOperationsStatus')
      .description('Read Permission Operations Status')
      .requiredOption(
        '--statusId <value>',
        'status id of the permission operations.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const statusId = cmd.statusId
        const links = cmd.links

        const op = await getOp()

        return op
          .getPermissionOperationsStatus({ statusId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
