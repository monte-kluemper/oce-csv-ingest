#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).itemsSearch
    }

    program.version('2020.03.05')
    program
      .command('getItemsForManagement')
      .description('Query Items')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Many such query conditions can be joined using AND/OR operators and grouped with parentheses. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. In case of query across type the field names are limited to standard fields (<i>id</i>, <i>type</i>, <i>name</i>, <i>description</i>, <i>slug</i>, <i>translatable</i>, <i>language</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>, <i>repositoryId</i>, <i>status</i>, <i>channels</i>, <i>collections</i>, <i>tags</i>, <i>isPublished</i>, <i>languageIsMaster</i>, <i>taxonomies</i>). However in case of type specific query the field names are limited to standard fields and user defined fields (except fields of largeText data type). The only values allowed in the operator are <i>eq</i> (Equals), <i>co</i> (Contains), <i>sw</i> (Startswith), <i>ge</i> (Greater than or equals to), <i>le</i> (Less than or equals to), <i>gt</i> (Greater than), <i>lt</i> (Less than), <i>mt</i> (Matches), <i>sm</i> (Similar).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(name eq "John")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(type eq "Employee" AND name eq "John")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(type eq "Employee" AND ((name eq "John" AND field.age ge "40") OR fields.weight gt "70"))<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(taxonomies.categories.id eq "9E1A79EE600C4C4BB727FE3E39E95489" OR (taxonomies.categories.name co "cat" AND taxonomies.categories.name co "red"))<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(taxonomies.categories.nodes.id eq "9E1A79EE600C4C4BB727FE3E39E95489" OR taxonomies.categories.nodes.name co "cars")'
      )
      .option(
        '--default <value>',
        'Default search query expression, that matches values of the items across all fields.'
      )
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields in each item in the result. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each items in the result. All the field name are case-sensitive, and users must provide the correct field name in the query. All the user-defined field names should be provided with prefix fields and followed by period (.). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard fields are returned in case of query across types and in case of type specific query, all standard and user fields are returned. This parameter is optional in the query, and by default the result shows only standard fields name, description. The standard fields <i>id</i>, <i>type</i> are always returned irrespective of any field asked. Any incorrect or invalid field name given in the query will throw an error.<br><br><b>Example</b>: This returns standard fields <i>name</i>, user fields <i>state</i> and <i>country</i> of type <i>Address</i> in the search results. <br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=fields.state,fields.country <br><br><b>Example</b>: This returns all the attributes for a specific type used in the search results.<br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=all<br><br><b>Example</b>: This returns standard fields <i>name</i>, <i>createdBy</i> in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=name,createdBy<br><br><b>Example</b>: This returns all the standard fields in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=all'
      )
      .option(
        '--repositoryId <value>',
        'This parameter accepts id of a repository and is used to control the returned results. The result will contain only items belonging to the specified repository. This can also be achieved by specifying the repositoryId (standard field of an item) equals query condition (<i>repositoryId eq "{repositoryId}"</i>) as one of the query conditions in the <b>q</b> query parameter. This is an optional parameter and by default returns results from all the repositories.'
      )
      .option(
        '--channelToken <value>',
        'This parameter accepts channelToken of a channel and is used to control the returned results. The result will contain only items, targeted to the channel that the specified channelToken belongs to. This can also be achieved by specifying the channels (standard field of an item) contains query condition (<i>channels co "{channelId}"</i>) as one of the query conditions in the <b>q</b> query parameter. This is an optional parameter and by default returns all the results.'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer less than 10000 and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result. If offset+limit > 10000, then we treat limit as 10000-offset and gives results.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--orderBy <value>',
        'The orderBy parameter is used to control the order (ascending/descending) of queried items.<br/>This parameter is optional in the query and by default the results are sorted by <i>updatedDate</i> when <i>default</i> parameter is empty. When <i>default</i> parameter has value(s), the results are sorted by the relevance of <i>tags</i> of the items to the default values.<br/><br/> This parameter accepts a field name separated by a colon (:) ,for which the user wants to sort the results and sort order. <br> format : <i><b>orderBy={fieldName}:{asc/desc}</b></i> (*Note : asc stands for ascending and desc for descending. asc and desc are always in lower case.) <br> In a type-specific query, field names can be either standard fields (<i>name</i>, <i>createdDate</i>, <i>updatedDate</i>) or user-defined fields (single-valued data types (<i>number, decimal, datetime</i>). But in case of a query across types, only <i>name</i>, <i>createdDate</i> and <i>updatedDate</i> (Standard fields) are allowed. All the user-defined field names should be provided with prefix fields and followed by a period (.). <br> <b>Example</b> : <i>orderBy=name:asc</i> <br> Returns all the items in the ascending order of name.</td><br/> <b>Example</b> : <i>orderBy=updateDate:asc</i> <br>Returns all the items in the ascending order of updateDate.<br/> <b>Example</b> : <i>orderBy=fields.age:desc</i> <br>Returns all the items in the descending order of age.<br/> <b>Example</b> : <i>orderBy=fields.age</i> <br> Returns all the items in the ascending order of age.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const q = cmd.q
        const _default = cmd.default
        const fields = cmd.fields
        const repositoryId = cmd.repositoryId
        const channelToken = cmd.channelToken
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults
        const orderBy = cmd.orderBy
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemsForManagement({
            q,
            _default,
            fields,
            repositoryId,
            channelToken,
            offset,
            limit,
            totalResults,
            orderBy,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getSimilarItems')
      .description('Query Similar Items')
      .option(
        '--prefer <value>',
        'This parameter is used to control the interaction type (synchronous/asynchronous) of the request. If the header is provided with value respond-async, it indicates that asynchronous interaction is preferred. Otherwise, synchronous interaction is preferred. Asynchronous request is responded with 202 status with a status link in the location header. Synchronous request is responded with 200 along with response body.'
      )
      .requiredOption('--id <value>', 'id of the item.(Digital Asset)')
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. Many such query conditions can be joined using AND/OR operators and grouped with parentheses. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. In case of query across type the field names are limited to standard fields (<i>id</i>, <i>type</i>, <i>name</i>, <i>description</i>, <i>slug</i>, <i>translatable</i>, <i>language</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>, <i>repositoryId</i>, <i>status</i>, <i>channels</i>, <i>collections</i>, <i>tags</i>, <i>isPublished</i>, <i>languageIsMaster</i>, <i>taxonomies</i>). However in case of type specific query the field names are limited to standard fields and user defined fields (except fields of largeText data type). The only values allowed in the operator are <i>eq</i> (Equals), <i>co</i> (Contains), <i>sw</i> (Startswith), <i>ge</i> (Greater than or equals to), <i>le</i> (Less than or equals to), <i>gt</i> (Greater than), <i>lt</i> (Less than), <i>mt</i> (Matches), <i>sm</i> (Similar).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(name eq "John")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(type eq "Employee" AND name eq "John")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(type eq "Employee" AND ((name eq "John" AND field.age ge "40") OR fields.weight gt "70"))<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(taxonomies.categories.id eq "9E1A79EE600C4C4BB727FE3E39E95489" OR (taxonomies.categories.name co "cat" AND taxonomies.categories.name co "red"))<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(taxonomies.categories.nodes.id eq "9E1A79EE600C4C4BB727FE3E39E95489" OR taxonomies.categories.nodes.name co "cars")'
      )
      .option(
        '--default <value>',
        'Default search query expression, that matches values of the items across all fields.'
      )
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields in each item in the result. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each items in the result. All the field name are case-sensitive, and users must provide the correct field name in the query. All the user-defined field names should be provided with prefix fields and followed by period (.). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard fields are returned in case of query across types and in case of type specific query, all standard and user fields are returned. This parameter is optional in the query, and by default the result shows only standard fields name, description. The standard fields <i>id</i>, <i>type</i> are always returned irrespective of any field asked. Any incorrect or invalid field name given in the query will throw an error.<br><br><b>Example</b>: This returns standard fields <i>name</i>, user fields <i>state</i> and <i>country</i> of type <i>Address</i> in the search results. <br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=fields.state,fields.country <br><br><b>Example</b>: This returns all the attributes for a specific type used in the search results.<br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=all<br><br><b>Example</b>: This returns standard fields <i>name</i>, <i>createdBy</i> in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=name,createdBy<br><br><b>Example</b>: This returns all the standard fields in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=all'
      )
      .option(
        '--channelToken <value>',
        'This parameter accepts channelToken of a channel and is used to control the returned results. The result will contain only items, targeted to the channel that the specified channelToken belongs to. This can also be achieved by specifying the channels (standard field of an item) contains query condition (<i>channels co "{channelId}"</i>) as one of the query conditions in the <b>q</b> query parameter. This is an optional parameter and by default returns all the results.'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const prefer = cmd.prefer
        const id = cmd.id
        const q = cmd.q
        const _default = cmd.default
        const fields = cmd.fields
        const channelToken = cmd.channelToken
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .getSimilarItems({
            prefer,
            id,
            q,
            _default,
            fields,
            channelToken,
            offset,
            limit,
            totalResults,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getSimilarItemsJobStatus')
      .description('Get Similar Items Job Status')
      .requiredOption('--statusId <value>', 'status id of similar items job.')
      .requiredOption('--id <value>', 'id of the item.(Digital Asset)')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const statusId = cmd.statusId
        const id = cmd.id
        const links = cmd.links

        const op = await getOp()

        return op
          .getSimilarItemsJobStatus({ statusId, id, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
