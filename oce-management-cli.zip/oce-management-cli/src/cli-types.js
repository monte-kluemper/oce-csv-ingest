#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).types
    }

    program.version('2020.03.05')
    program
      .command('listDataTypes')
      .description('List All Data Types')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links

        const op = await getOp()

        return op
          .listDataTypes({ links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listTypes')
      .description('List All Types')
      .option(
        '--roleName <value>',
        'This parameter is used to filter the returned types with the given role name. This parameter is optional in the query and by default all the types are returned.'
      )
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>roleName</b></i>, <i><b>repositoryId</b></i> and <i><b>name</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on the others. This query param is optional and defaults to <i><b>roleName eq "viewer"</b></i> which filters the resources with at least given role. <i><b>name</b></i> is interpreted in the context of the resource being requested. For eg. name for content types implies content type name.<br><b>Example</b>:<br> ?q=roleName eq "manager")'
      )
      .option(
        '--isRoleByShare <value>',
        'This parameter is used to filter the returned results explicitly shared to the user. This parameter is optional in the query and by default it is set to false.'
      )
      .option(
        '--fields <value>',
        'This parameter is used to control the returned fields in each type in the list. All the field names are case-sensitive. Each type has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>, <i>roleName</i>, <i>allowedActions</i>) and additional fields (<i>fields</i>, <i>properties</i>, <i>connectorInfos</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. The user can filter out only the additional fields. This parameter is optional in the query, and by default the result shows all standard and additional fields in the response. Any incorrect or invalid field name given in the query will throw an error. <br><br> <b>Example</b>: <i>?fields=fields,connectorInfos</i> <br> This returns all standard fields along with the <i>fields</i> and <i>connectorInfos</i> additional fields for each type.<br> <b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each type. <br> '
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--orderBy <value>',
        'This parameter is used to control the order of results. The value of this query parameter follows the format of <i> fieldName:[asc/desc]</i>. <i>asc</i> stands for ascending order  <i>desc</i> stands for descending order, default order is <i>asc</i>.The only fields allowed in the field name are <b>name</b> and <b>updatedDate</b>.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .action(async cmd => {
        const roleName = cmd.roleName
        const q = cmd.q
        const isRoleByShare = cmd.isRoleByShare
        const fields = cmd.fields
        const links = cmd.links
        const offset = cmd.offset
        const limit = cmd.limit
        const orderBy = cmd.orderBy
        const totalResults = cmd.totalResults

        const op = await getOp()

        return op
          .listTypes({
            roleName,
            q,
            isRoleByShare,
            fields,
            links,
            offset,
            limit,
            orderBy,
            totalResults
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('createType')
      .description('Create a Type')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createType({ links, body, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getType')
      .description('Read a Type')
      .requiredOption('--name <value>', 'Type name identifier.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const name = cmd.name
        const links = cmd.links
        const fields = cmd.fields

        const op = await getOp()

        return op
          .getType({ name, links, fields })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('updateType')
      .description('Update a Type')
      .requiredOption('--name <value>', 'Type name identifier.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const name = cmd.name
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .updateType({ name, body, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('deleteType')
      .description('Delete a Type')
      .requiredOption('--name <value>', 'Type name identifier.')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const name = cmd.name
        const links = cmd.links

        const op = await getOp()

        return op
          .deleteType({ name, links, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listTypePermissions')
      .description('List All Permissions on a Type')
      .requiredOption('--name <value>', 'Type name identifier.')
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .action(async cmd => {
        const name = cmd.name
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults
        const links = cmd.links

        const op = await getOp()

        return op
          .listTypePermissions({ name, offset, limit, totalResults, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
