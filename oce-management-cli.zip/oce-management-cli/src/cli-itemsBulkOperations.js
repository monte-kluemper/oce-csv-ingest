#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).itemsBulkOperations
    }

    program.version('2020.03.05')
    program
      .command('itemsBulkUpdate')
      .description('Performs Bulk Items Operations')
      .option(
        '--prefer <value>',
        'This parameter is used to control the interaction type (synchronous/asynchronous) of the request. If the header is provided with value respond-async, it indicates that asynchronous interaction is preferred. Otherwise, synchronous interaction is preferred. Asynchronous request is responded with 202 status with a status link in the location header. Synchronous request is responded with 200 along with response body.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const prefer = cmd.prefer
        const links = cmd.links
        const body = await readStdIn()
        const op = await getOp()

        return op
          .itemsBulkUpdate({
            body,
            prefer,
            links,
            xRequestedWith: 'XMLHttpRequest'
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getBulkUpdatePublishJobItemIds')
      .description('Read Items Bulk Operations Publish Item ids')
      .requiredOption(
        '--statusId <value>',
        'status id of the bulk items publish operation.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .action(async cmd => {
        const statusId = cmd.statusId
        const links = cmd.links
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults

        const op = await getOp()

        return op
          .getBulkUpdatePublishJobItemIds({
            statusId,
            links,
            offset,
            limit,
            totalResults
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getBulkUpdateJobStatus')
      .description('Read Items Bulk Operations Status')
      .requiredOption(
        '--statusId <value>',
        'status id of the bulk items operations.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const statusId = cmd.statusId
        const links = cmd.links

        const op = await getOp()

        return op
          .getBulkUpdateJobStatus({ statusId, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
