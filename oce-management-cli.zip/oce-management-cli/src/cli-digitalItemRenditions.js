#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).digitalItemRenditions
    }

    program.version('2020.03.05')
    program
      .command('getNativeManagement')
      .description('Get Digital Item Native File')
      .requiredOption('--id <value>', 'id of the item.')
      .option(
        '--download <value>',
        'By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default.'
      )
      .option(
        '--asOf <value>',
        'This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version.'
      )
      .action(async cmd => {
        const id = cmd.id
        const download = cmd.download
        const asOf = cmd.asOf

        const op = await getOp()

        return op
          .getNativeManagement({ id, download, asOf })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getNativeManagementWithFileName')
      .description('Get Digital Item Native File with Filename')
      .requiredOption('--id <value>', 'id of the item.')
      .requiredOption('--filename <value>', 'Name of the digital item.')
      .option(
        '--download <value>',
        'By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default.'
      )
      .option(
        '--asOf <value>',
        'This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version.'
      )
      .action(async cmd => {
        const id = cmd.id
        const filename = cmd.filename
        const download = cmd.download
        const asOf = cmd.asOf

        const op = await getOp()

        return op
          .getNativeManagementWithFileName({ id, filename, download, asOf })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getManagementRenditionWithFileName_1')
      .description('Get Rendition of a Digital Item with Filename')
      .requiredOption('--id <value>', 'id of the item.')
      .requiredOption(
        '--rendition <value>',
        'Rendition name of the digital item.'
      )
      .requiredOption('--version <value>', 'The version of an item revision')
      .requiredOption('--filename <value>', 'Name of the digital item.')
      .option(
        '--format <value>',
        'Format of the digital item\'s rendition file. When the rendition has only one format, the format query parameter may be omitted.'
      )
      .option('--type <value>', 'Rendition type of the digital item.')
      .option(
        '--download <value>',
        'By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default.'
      )
      .action(async cmd => {
        const id = cmd.id
        const rendition = cmd.rendition
        const version = cmd.version
        const filename = cmd.filename
        const format = cmd.format
        const type = cmd.type
        const download = cmd.download

        const op = await getOp()

        return op
          .getManagementRenditionWithFileName_1({
            id,
            rendition,
            version,
            filename,
            format,
            type,
            download
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getManagementRendition')
      .description('Get Rendition of a Digital Item')
      .requiredOption('--id <value>', 'id of the item.')
      .requiredOption(
        '--rendition <value>',
        'Rendition name of the digital item.'
      )
      .option(
        '--format <value>',
        'Format of the digital item\'s rendition file. When the rendition has only one format, the format query parameter may be omitted.'
      )
      .option('--type <value>', 'Rendition type of the digital item.')
      .option(
        '--download <value>',
        'By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default.'
      )
      .option(
        '--asOf <value>',
        'This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version.'
      )
      .action(async cmd => {
        const id = cmd.id
        const rendition = cmd.rendition
        const format = cmd.format
        const type = cmd.type
        const download = cmd.download
        const asOf = cmd.asOf

        const op = await getOp()

        return op
          .getManagementRendition({
            id,
            rendition,
            format,
            type,
            download,
            asOf
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getManagementRenditionWithFileName')
      .description('Get Rendition of a Digital Item with Filename')
      .requiredOption('--id <value>', 'id of the item.')
      .requiredOption(
        '--rendition <value>',
        'Rendition name of the digital item.'
      )
      .requiredOption('--filename <value>', 'Name of the digital item.')
      .option(
        '--format <value>',
        'Format of the digital item\'s rendition file. When the rendition has only one format, the format query parameter may be omitted.'
      )
      .option('--type <value>', 'Rendition type of the digital item.')
      .option(
        '--download <value>',
        'By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default.'
      )
      .option(
        '--asOf <value>',
        'This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version.'
      )
      .action(async cmd => {
        const id = cmd.id
        const rendition = cmd.rendition
        const filename = cmd.filename
        const format = cmd.format
        const type = cmd.type
        const download = cmd.download
        const asOf = cmd.asOf

        const op = await getOp()

        return op
          .getManagementRenditionWithFileName({
            id,
            rendition,
            filename,
            format,
            type,
            download,
            asOf
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
