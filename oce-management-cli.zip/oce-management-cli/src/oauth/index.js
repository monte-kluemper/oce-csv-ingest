const { getAuth } = require('./login-oauth')
module.exports = getAuth
