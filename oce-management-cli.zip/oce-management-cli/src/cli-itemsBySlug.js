#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).itemsBySlug
    }

    program.version('2020.03.05')
    program
      .command('getItemBySlug')
      .description('Read an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--expand <value>',
        'Expand parameter provides the option of getting child resources (referenced items) inline with the item\'s response. Accepts a comma-separated list of field names or <i>all</i>. All the user-defined field names should be provided with prefix <i>fields</i> and followed by a period (.). If these fields are of a reference type, then the resource expands their data inline in the response. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the reference type of the requested item are expanded. When expand is not specified, item response contains links to the referenced items. Expansion of this form is supported for one level only; a request to expand beyond the first level of referenced fields will produce the response HTTP 400. When the expand parameter contains a nonexistent field as per type definition of the requested item, the resource produces HTTP 400.<br><br><b>Example</b> : expand=<i>fields.field1,fields.field2</i> <br>Returns field1 and field2: names of the user-defined fields in the type to which this item belongs.<br><b>Example</b> : expand=<i>taxonomies</i> <br>Returns taxonomies field containing all categories assigned to this item.<br><b>Example</b> : expand=<i>all</i> <br>Returns all fields available for this item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .option(
        '--asOf <value>',
        'This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version. The slug value passed in the url should always be that of the latest management item.'
      )
      .option(
        '--asOfDate <value>',
        'This parameter defines a point of time as of which the item revision should be returned. The date string format is <i>yyyy-MM-dd\'T\'HH:mm:ss\'Z\'</i> or <i>yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'</i>.  The slug value passed in the url should always be that of the latest management item.'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const expand = cmd.expand
        const links = cmd.links
        const asOf = cmd.asOf
        const asOfDate = cmd.asOfDate

        const op = await getOp()

        return op
          .getItemBySlug({ slug, expand, links, asOf, asOfDate })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemChannelsBySlug')
      .description('List Channels of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemChannelsBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemCollectionsBySlug')
      .description('List Collections of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemCollectionsBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemPublishInfoBySlug')
      .description('List Publish Info of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemPublishInfoBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemPublishedChannelsBySlug')
      .description('List Published Channels of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemPublishedChannelsBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemRelationsBySlug')
      .description('List Relationships of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemRelationsBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemTagsBySlug')
      .description('List Tags of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemTagsBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemTaxonomiesBySlug')
      .description('List Taxonomies of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemTaxonomiesBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemVariationsBySlug')
      .description('List Variations of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemVariationsBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listVariationsByTypeBySlug')
      .description('List all Item Variations of a Variation Type by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .requiredOption(
        '--variationType <value>',
        'Type of the variation. Possible value: <i>language</i>'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const variationType = cmd.variationType
        const links = cmd.links

        const op = await getOp()

        return op
          .listVariationsByTypeBySlug({ slug, variationType, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getMasterItemBySlug')
      .description('Read master of an Item Variation set by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .requiredOption(
        '--variationType <value>',
        'Type of the variation. Possible value: <i>language</i>'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const variationType = cmd.variationType
        const links = cmd.links

        const op = await getOp()

        return op
          .getMasterItemBySlug({ slug, variationType, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('getItemForVariationBySlug')
      .description('Read Item Variation of a Variation Type Value by slug')
      .option('--channelToken <value>', 'Channel token of the target channel.')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .requiredOption(
        '--variationType <value>',
        'Type of the variation. Possible value: <i>language</i>'
      )
      .requiredOption(
        '--variationValue <value>',
        'Value of the variation type. Example: <i>en-US</i>, <i>fr</i> etc.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const channelToken = cmd.channelToken
        const slug = cmd.slug
        const variationType = cmd.variationType
        const variationValue = cmd.variationValue
        const links = cmd.links

        const op = await getOp()

        return op
          .getItemForVariationBySlug({
            channelToken,
            slug,
            variationType,
            variationValue,
            links
          })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program
      .command('listItemVersionInfoBySlug')
      .description('List Version Info of an Item by slug')
      .requiredOption(
        '--slug <value>',
        'Slug value of the latest management Item.'
      )
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>'
      )
      .action(async cmd => {
        const slug = cmd.slug
        const links = cmd.links

        const op = await getOp()

        return op
          .listItemVersionInfoBySlug({ slug, links })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
