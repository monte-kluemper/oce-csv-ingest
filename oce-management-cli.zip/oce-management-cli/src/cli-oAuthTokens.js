#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).oAuthTokens
    }

    program.version('2020.03.05')
    program
      .command('createToken')
      .description('Generate an OAuth Token')
      .requiredOption(
        '--id <value>',
        'Generates an OAuth token for the given channelId'
      )
      .action(async cmd => {
        const id = cmd.id
        const body = await readStdIn()
        const op = await getOp()

        return op
          .createToken({ id, body, xRequestedWith: 'XMLHttpRequest' })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
