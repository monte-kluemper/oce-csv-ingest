#!/usr/bin/env node
if (require.main === module) {
  ;(async () => {
    const program = require('commander')
    const { readConfig, readStdIn, responseHandler } = require('./cli-util')
    const getOp = async () => {
      const { host, auth } = await readConfig()
      if (process.stdout.isTTY) console.log('Using OCE at ' + host)

      const { client } = require('./client')
      return client(host, auth).connectors
    }

    program.version('2020.03.05')
    program
      .command('getConnectors')
      .description('List All Connectors')
      .option(
        '--links <value>',
        'This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>'
      )
      .option(
        '--offset <value>',
        'This parameter accepts a non negative integer and is used to control the start index of the result.'
      )
      .option(
        '--limit <value>',
        'This parameter accepts a non negative integer and is used to control the size of the result.'
      )
      .option(
        '--totalResults <value>',
        'This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count.'
      )
      .option(
        '--q <value>',
        'This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>name</b></i> and <i><b>connectorType</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on <i><b>connectorType</b></i>. This query param is optional with no default.<br><b>Example</b>:<br> ?q=name co "foo")<br><b>Example</b>:<br> ?q=connectorType eq "translation")<br><b>Example</b>:<br> ?q=connectorType eq "content")'
      )
      .action(async cmd => {
        const links = cmd.links
        const offset = cmd.offset
        const limit = cmd.limit
        const totalResults = cmd.totalResults
        const q = cmd.q

        const op = await getOp()

        return op
          .getConnectors({ links, offset, limit, totalResults, q })
          .then(responseHandler)
          .catch(err => {
            console.error(err)
          })
      })

    program.on('command:*', function () {
      console.error('Invalid command: %s\n', program.args.join(' '))
      program.help()
      process.exit(1)
    })
    await program.parseAsync(process.argv)
    // if not command is found, print help
    if (process.argv.length === 2) {
      // e.g. display usage
      program.help()
    }
  })().catch(console.error)
}
