const querystring = require('querystring')
const fetch = require('node-fetch')
const https = require('https')
const debug = require('debug')('oce-fetch')
const toQS = queryParams => {
  for (const propName in queryParams) {
    if (queryParams[propName] === null || queryParams[propName] === undefined) {
      delete queryParams[propName]
    }
  }
  return Object.keys(queryParams).length > 0
    ? '?' + querystring.stringify(queryParams)
    : ''
}
const agent = new https.Agent({ keepAlive: true })

/** Channel Secret */
const channelSecret_ = (host, authorization) => {
  /**  @function createChannelSecret - Generate a channel secret.
   * @param {string} id - Generates a secret for the given channelId.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createChannelSecret = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/channels/{id}/channelSecret'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function refreshChannelSecret - Refresh channel secret.
   * @param {string} id - Refreshes secret for the given channelId.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const refreshChannelSecret = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/channels/{id}/channelSecret'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteSecretKey - Delete the channel secret.
   * @param {string} id - Deletes the secret for the given channelId.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteSecretKey = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/channels/{id}/channelSecret'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return { createChannelSecret, refreshChannelSecret, deleteSecretKey }
}
/** Channels */
const channels_ = (host, authorization) => {
  /**  @function listChannels - List All Channels.
   * @param {string} roleName - This parameter is used to filter the returned channels with the given role name. This parameter is optional in the query and by default all the channels are returned..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>roleName</b></i>, <i><b>repositoryId</b></i> and <i><b>name</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on the others. This query param is optional and defaults to <i><b>roleName eq "viewer"</b></i> which filters the resources with at least given role. <i><b>name</b></i> is interpreted in the context of the resource being requested. For eg. name for content types implies content type name.<br><b>Example</b>:<br> ?q=roleName eq "manager").
   * @param {string} fields - This parameter is used to control the returned fields in each channel in the list. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each channel in the list. All the field names are case-sensitive, and users must provide the correct field names in the query. Each channel has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>, <i>isSiteChannel</i>) and additional fields (<i>channelType</i>, <i>publishPolicy</i>, <i>localizationPolicy</i>, <i>channelTokens</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. The user can filter out only the additional fields. This parameter is optional in the query, and by default the result shows only standard fields in the response. Any incorrect or invalid field name given in the query will throw an error. <br><br> <b>Example</b>: <i>?fields=channelTokens,localizationPolicy</i> <br> This returns all standard fields along with the <i>channelTokens</i> and <i>localizationPolicy</i> additional fields for each channel.<br> <b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each channel. <br> .
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - This parameter is used to control the order of results. The value of this query parameter follows the format of <i> fieldName:[asc/desc]</i>. <i>asc</i> stands for ascending order  <i>desc</i> stands for descending order, default order is <i>asc</i>. The only field names allowed are <b>name</b> and <b>updatedDate</b>..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const listChannels = ({
    roleName,
    q,
    fields,
    offset,
    limit,
    orderBy,
    totalResults,
    links
  }) => {
    const queryParams = {
      roleName: roleName,
      q: q,
      fields: fields,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/channels' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createChannel - Create a Channel.
   * @param {undefined} body - Creates a channel with the given information in the payload. The fields <i>id, createdBy, createdDate, updatedBy, updatedDate, channelTokens, isSiteChannel</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createChannel = ({ body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/channels' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getChannel - Read a Channel.
   * @param {string} id - id of the channel..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getChannel = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/channels/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateChannel - Update a Channel.
   * @param {string} id - id of the channel..
   * @param {undefined} body - Updates a channel with the given information in the payload. The fields <i>createdBy, createdDate, updatedBy, updatedDate, channelTokens, isSiteChannel</i>and <i>links</i> will be ignored even if given in the payload. This payload is optional if the endpoint is being used to refresh the channel token..
   * @param {boolean} refreshTokens - Refresh Token.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateChannel = ({
    id,
    body,
    refreshTokens,
    links,
    xRequestedWith
  }) => {
    const queryParams = { refreshTokens: refreshTokens, links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/channels/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteChannel - Delete a Channel.
   * @param {string} id - id of the channel..
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteChannel = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/channels/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listChannelPermissions - List All Permissions on a Channel.
   * @param {string} id - id of the channel..
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const listChannelPermissions = ({
    id,
    offset,
    limit,
    totalResults,
    links
  }) => {
    const queryParams = {
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/channels/{id}/permissions'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    listChannels,
    createChannel,
    getChannel,
    updateChannel,
    deleteChannel,
    listChannelPermissions
  }
}
/** Collections */
const collections_ = (host, authorization) => {
  /**  @function listCollections - List All Collections in a Repository.
   * @param {string} id - Repository id parameter for collections..
   * @param {string} fields - This parameter is used to control the returned fields in each collection in the list. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each collection in the list. All the field names are case-sensitive,and users must provide the correct field names in the query. Each collection has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>) and additional fields (<i>repository</i>, <i>channels</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. The user can filter out only the additional fields. This parameter is optional in the query, and by default the result shows only standard fields in the response. Any incorrect or invalid field name given in the query will throw an error. <br><br> <b>Example</b>: <i>?fields=channels</i> <br> This returns all standard fields along with the <i>channels</i> additional fields for each collection.<br> <b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each collection. <br> .
   * @param {string} roleName - This parameter is used to filter the returned collections with the given role name..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>roleName</b></i>, <i><b>repositoryId</b></i> and <i><b>name</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on the others. This query param is optional and defaults to <i><b>roleName eq "viewer"</b></i> which filters the resources with at least given role. <i><b>name</b></i> is interpreted in the context of the resource being requested. For eg. name for content types implies content type name.<br><b>Example</b>:<br> ?q=roleName eq "manager").
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - This parameter is used to control the order of results. The value of this query parameter follows the format of <i> fieldName:[asc/desc]</i>. <i>asc</i> stands for ascending order  <i>desc</i> stands for descending order, and the default order is <i>asc</i>. The only field names allowed are <b>name</b> and <b>updatedDate</b>..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const listCollections = ({
    id,
    fields,
    roleName,
    q,
    offset,
    limit,
    orderBy,
    totalResults,
    links
  }) => {
    const queryParams = {
      fields: fields,
      roleName: roleName,
      q: q,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/repositories/{id}/collections'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createCollection - Create a Collection.
   * @param {string} id - Repository id parameter for collections..
   * @param {undefined} body - Creates a collection with the given information in the payload. The fields <i>id, createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createCollection = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/repositories/{id}/collections'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getCollection - Read a Collection.
   * @param {string} id - Repository id parameter for collections..
   * @param {string} collectionId - id of the collection..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getCollection = ({ id, collectionId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/repositories/{id}/collections/{collectionId}'
        .replace('{id}', id)
        .replace('{collectionId}', collectionId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateCollection - Update a Collection.
   * @param {string} id - Repository id parameter for collections..
   * @param {string} collectionId - id of the collection..
   * @param {undefined} body - Updates a collection with the given information in the payload. The fields <i>createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateCollection = ({
    id,
    collectionId,
    body,
    links,
    xRequestedWith
  }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/repositories/{id}/collections/{collectionId}'
        .replace('{id}', id)
        .replace('{collectionId}', collectionId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteCollection - Delete a Collection.
   * @param {string} id - Repository id parameter for collections..
   * @param {string} collectionId - id of the collection..
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteCollection = ({ id, collectionId, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/repositories/{id}/collections/{collectionId}'
        .replace('{id}', id)
        .replace('{collectionId}', collectionId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listCollectionPermissions - List All Permissions on a Collection.
   * @param {string} id - Repository id parameter for collections..
   * @param {string} collectionId - id of the collection..
   * @param {boolean} isCollectionOnly - This parameter accepts a boolean value. If true, retrieves the list of users with whom the collection is explicitly shared. If false, retrieves the list of users who have access to the collection (through direct and inherited from repository sharing). Default value is false..
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const listCollectionPermissions = ({
    id,
    collectionId,
    isCollectionOnly,
    offset,
    limit,
    totalResults,
    links
  }) => {
    const queryParams = {
      isCollectionOnly: isCollectionOnly,
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/repositories/{id}/collections/{collectionId}/permissions'
        .replace('{id}', id)
        .replace('{collectionId}', collectionId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    listCollections,
    createCollection,
    getCollection,
    updateCollection,
    deleteCollection,
    listCollectionPermissions
  }
}
/** Connectors */
const connectors_ = (host, authorization) => {
  /**  @function getConnectors - List All Connectors.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>name</b></i> and <i><b>connectorType</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on <i><b>connectorType</b></i>. This query param is optional with no default.<br><b>Example</b>:<br> ?q=name co "foo")<br><b>Example</b>:<br> ?q=connectorType eq "translation")<br><b>Example</b>:<br> ?q=connectorType eq "content").
   */
  const getConnectors = ({ links, offset, limit, totalResults, q }) => {
    const queryParams = {
      links: links,
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      q: q
    }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/connectors' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return { getConnectors }
}
/** Digital Item Renditions */
const digitalItemRenditions_ = (host, authorization) => {
  /**  @function getNativeManagement - Get Digital Item Native File.
   * @param {string} id - id of the item..
   * @param {boolean} download - By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default..
   * @param {string} asOf - This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version..
   */
  const getNativeManagement = ({ id, download, asOf }) => {
    const queryParams = { download: download, asOf: asOf }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/assets/{id}/native'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getNativeManagementWithFileName - Get Digital Item Native File with Filename.
   * @param {string} id - id of the item..
   * @param {string} filename - Name of the digital item..
   * @param {boolean} download - By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default..
   * @param {string} asOf - This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version..
   */
  const getNativeManagementWithFileName = ({
    id,
    filename,
    download,
    asOf
  }) => {
    const queryParams = { download: download, asOf: asOf }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/assets/{id}/native/{filename}'
        .replace('{id}', id)
        .replace('{filename}', filename) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getManagementRenditionWithFileName_1 - Get Rendition of a Digital Item with Filename.
   * @param {string} id - id of the item..
   * @param {string} rendition - Rendition name of the digital item..
   * @param {number} version - The version of an item revision.
   * @param {string} filename - Name of the digital item..
   * @param {string} format - Format of the digital item's rendition file. When the rendition has only one format, the format query parameter may be omitted..
   * @param {string} type - Rendition type of the digital item..
   * @param {boolean} download - By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default..
   */
  const getManagementRenditionWithFileName_1 = ({
    id,
    rendition,
    version,
    filename,
    format,
    type,
    download
  }) => {
    const queryParams = { format: format, type: type, download: download }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/assets/{id}/versions/{version}/{rendition}/{filename}'
        .replace('{id}', id)
        .replace('{rendition}', rendition)
        .replace('{version}', version)
        .replace('{filename}', filename) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getManagementRendition - Get Rendition of a Digital Item.
   * @param {string} id - id of the item..
   * @param {string} rendition - Rendition name of the digital item..
   * @param {string} format - Format of the digital item's rendition file. When the rendition has only one format, the format query parameter may be omitted..
   * @param {string} type - Rendition type of the digital item..
   * @param {boolean} download - By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default..
   * @param {string} asOf - This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version..
   */
  const getManagementRendition = ({
    id,
    rendition,
    format,
    type,
    download,
    asOf
  }) => {
    const queryParams = {
      format: format,
      type: type,
      download: download,
      asOf: asOf
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/assets/{id}/{rendition}'
        .replace('{id}', id)
        .replace('{rendition}', rendition) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getManagementRenditionWithFileName - Get Rendition of a Digital Item with Filename.
   * @param {string} id - id of the item..
   * @param {string} rendition - Rendition name of the digital item..
   * @param {string} filename - Name of the digital item..
   * @param {string} format - Format of the digital item's rendition file. When the rendition has only one format, the format query parameter may be omitted..
   * @param {string} type - Rendition type of the digital item..
   * @param {boolean} download - By default, for files of type image, audio and video are rendered inline. For all other file types are downloaded. User can specify the query parameter download=true/false in a request to override this default..
   * @param {string} asOf - This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version..
   */
  const getManagementRenditionWithFileName = ({
    id,
    rendition,
    filename,
    format,
    type,
    download,
    asOf
  }) => {
    const queryParams = {
      format: format,
      type: type,
      download: download,
      asOf: asOf
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/assets/{id}/{rendition}/{filename}'
        .replace('{id}', id)
        .replace('{rendition}', rendition)
        .replace('{filename}', filename) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    getNativeManagement,
    getNativeManagementWithFileName,
    getManagementRenditionWithFileName_1,
    getManagementRendition,
    getManagementRenditionWithFileName
  }
}
/** Item Revisions */
const itemRevisions_ = (host, authorization) => {
  /**  @function getItemRevisionsBySlug - List item revisions by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getItemRevisionsBySlug = ({
    slug,
    offset,
    limit,
    totalResults,
    links
  }) => {
    const queryParams = {
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/versions'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemRevisionBySlug - Read an item revision by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {number} version - The version of an item revision.
   * @param {string} expand - Expand parameter provides the option of getting child resources (referenced items) inline with the item's response. Accepts a comma-separated list of field names or <i>all</i>. All the user-defined field names should be provided with prefix <i>fields</i> and followed by a period (.). If these fields are of a reference type, then the resource expands their data inline in the response. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the reference type of the requested item are expanded. When expand is not specified, item response contains links to the referenced items. Expansion of this form is supported for one level only; a request to expand beyond the first level of referenced fields will produce the response HTTP 400. When the expand parameter contains a nonexistent field as per type definition of the requested item, the resource produces HTTP 400.<br>Examples : </br><ol>expand=<i>fields.field1,fields.field2</i></ol><ol>expand=<i>all</i></ol> where field1, field2 are names of the user-defined fields in the type to which this item belongs..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemRevisionBySlug = ({ slug, version, expand, links }) => {
    const queryParams = { expand: expand, links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/versions/{version}'
        .replace('{slug}', slug)
        .replace('{version}', version) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemRevisions - List item revisions.
   * @param {string} guid - id of the item..
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getItemRevisions = ({ guid, offset, limit, totalResults, links }) => {
    const queryParams = {
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{guid}/versions'.replace(
        '{guid}',
        guid
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemRevision - Read an item revision.
   * @param {string} guid - id of the item..
   * @param {number} version - The version of an item revision.
   * @param {string} expand - Expand parameter provides the option of getting child resources (referenced items) inline with the item's response. Accepts a comma-separated list of field names or <i>all</i>. All the user-defined field names should be provided with prefix <i>fields</i> and followed by a period (.). If these fields are of a reference type, then the resource expands their data inline in the response. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the reference type of the requested item are expanded. When expand is not specified, item response contains links to the referenced items. Expansion of this form is supported for one level only; a request to expand beyond the first level of referenced fields will produce the response HTTP 400. When the expand parameter contains a nonexistent field as per type definition of the requested item, the resource produces HTTP 400.<br>Examples : </br><ol>expand=<i>fields.field1,fields.field2</i></ol><ol>expand=<i>all</i></ol> where field1, field2 are names of the user-defined fields in the type to which this item belongs..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemRevision = ({ guid, version, expand, links }) => {
    const queryParams = { expand: expand, links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{guid}/versions/{version}'
        .replace('{guid}', guid)
        .replace('{version}', version) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    getItemRevisionsBySlug,
    getItemRevisionBySlug,
    getItemRevisions,
    getItemRevision
  }
}
/** Item Variations */
const itemVariations_ = (host, authorization) => {
  /**  @function listVariationsByType - List All Item Variations of a Variation Type.
   * @param {string} id - id of the item..
   * @param {string} variationType - Type of the variation. Possible value: <i>language</i>.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listVariationsByType = ({ id, variationType, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/variations/{variationType}'
        .replace('{id}', id)
        .replace('{variationType}', variationType) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getMasterItem - Read Item Variations by Variation Type.
   * @param {string} id - id of the item..
   * @param {string} variationType - Type of the variation. Possible value: <i>language</i>.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getMasterItem = ({ id, variationType, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/variations/{variationType}/master'
        .replace('{id}', id)
        .replace('{variationType}', variationType) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateMasterItem - Update Master Item of an Item Variations Set.
   * @param {string} id - id of the item..
   * @param {string} variationType - Type of the variation. Possible value: <i>language</i>.
   * @param {undefined} body - Item variation set payload.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateMasterItem = ({
    id,
    variationType,
    body,
    links,
    xRequestedWith
  }) => {
    const queryParams = { links: links }
    // consumes  UNKOWN
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/variations/{variationType}/master'
        .replace('{id}', id)
        .replace('{variationType}', variationType) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemForVariation - Read Item Variation of a Variation Type Value.
   * @param {string} channelToken - Channel token of the target channel..
   * @param {string} id - id of the item..
   * @param {string} variationType - Type of the variation. Possible value: <i>language</i>.
   * @param {string} variationValue - Value of the variation type. Example: <i>en-US</i>, <i>fr</i> etc..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemForVariation = ({
    channelToken,
    id,
    variationType,
    variationValue,
    links
  }) => {
    const queryParams = { channelToken: channelToken, links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/variations/{variationType}/{variationValue}'
        .replace('{id}', id)
        .replace('{variationType}', variationType)
        .replace('{variationValue}', variationValue) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    listVariationsByType,
    getMasterItem,
    updateMasterItem,
    getItemForVariation
  }
}
/** Items */
const items_ = (host, authorization) => {
  /**  @function createItem - Create an Item.
   * @param {undefined} body - Creates an item with the given information in the payload. The fields <i>id, createdBy, createdDate, updatedBy, updatedDate, </i><i>slug, variations, channels, collections, relationships, publishInfo</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createItem = ({ body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/items' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItem - Read an Item.
   * @param {string} id - id of the item..
   * @param {string} expand - Expand parameter provides the option of getting child resources (referenced items) inline with the item's response. Accepts a comma-separated list of field names or <i>all</i>. All the user-defined field names should be provided with prefix <i>fields</i> and followed by a period (.). If these fields are of a reference type, then the resource expands their data inline in the response. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the reference type of the requested item are expanded. When expand is not specified, item response contains links to the referenced items. Expansion of this form is supported for one level only; a request to expand beyond the first level of referenced fields will produce the response HTTP 400. When the expand parameter contains a nonexistent field as per type definition of the requested item, the resource produces HTTP 400.<br><br><b>Example</b> : expand=<i>fields.field1,fields.field2</i> <br>Returns field1 and field2: names of the user-defined fields in the type to which this item belongs.<br><b>Example</b> : expand=<i>taxonomies</i> <br>Returns taxonomies field containing all categories assigned to this item.<br><b>Example</b> : expand=<i>all</i> <br>Returns all fields available for this item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} asOf - This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version..
   * @param {string} asOfDate - This parameter defines a point of time as of which the item revision should be returned. The date string format is <i>yyyy-MM-dd'T'HH:mm:ss'Z'</i> or <i>yyyy-MM-dd'T'HH:mm:ss.SSS'Z'</i>..
   */
  const getItem = ({ id, expand, links, asOf, asOfDate }) => {
    const queryParams = {
      expand: expand,
      links: links,
      asOf: asOf,
      asOfDate: asOfDate
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateItem - Update an Item.
   * @param {undefined} body - Updates an item with the given information in the payload. The fields <i>createdBy, createdDate, updatedBy, updatedDate, </i><i>slug, variations, channels, collections, relationships, publishInfo</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateItem = ({ body, id, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteItem - Delete an Item.
   * @param {string} id - id of the item..
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteItem = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/items/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemChannels - List Channels of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemChannels = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/channels'.replace('{id}', id) +
      qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemCollections - List Collections of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemCollections = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/collections'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemPublishInfo - Read Publish Info of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemPublishInfo = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/publishInfo'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemPublishedChannels - List Published Channels of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemPublishedChannels = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/publishedChannels'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemsRelationships - List Relationships of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemsRelationships = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/relationships'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemTags - List Tags of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemTags = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/tags'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemTaxonomies - List all Taxonomies and Categories of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemTaxonomies = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/taxonomies'.replace('{id}', id) +
      qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function lisItemVariations - List Variations of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const lisItemVariations = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/variations'.replace('{id}', id) +
      qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemVersionInfo - Read Version Info of an Item.
   * @param {string} id - id of the item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemVersionInfo = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/versionInfo'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listTimeZones - List All Time Zones.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listTimeZones = ({ links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/timeZones' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    createItem,
    getItem,
    updateItem,
    deleteItem,
    listItemChannels,
    getItemCollections,
    getItemPublishInfo,
    listItemPublishedChannels,
    getItemsRelationships,
    getItemTags,
    getItemTaxonomies,
    lisItemVariations,
    getItemVersionInfo,
    listTimeZones
  }
}
/** Items Bulk Operations */
const itemsBulkOperations_ = (host, authorization) => {
  /**  @function itemsBulkUpdate - Performs Bulk Items Operations.
   * @param {undefined} body - Details of the bulk items operations..
   * @param {string} prefer - This parameter is used to control the interaction type (synchronous/asynchronous) of the request. If the header is provided with value respond-async, it indicates that asynchronous interaction is preferred. Otherwise, synchronous interaction is preferred. Asynchronous request is responded with 202 status with a status link in the location header. Synchronous request is responded with 200 along with response body..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const itemsBulkUpdate = ({ body, prefer, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/bulkItemsOperations' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      Prefer: prefer,
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getBulkUpdatePublishJobItemIds - Read Items Bulk Operations Publish Item ids.
   * @param {string} statusId - status id of the bulk items publish operation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   */
  const getBulkUpdatePublishJobItemIds = ({
    statusId,
    links,
    offset,
    limit,
    totalResults
  }) => {
    const queryParams = {
      links: links,
      offset: offset,
      limit: limit,
      totalResults: totalResults
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/bulkItemsOperations/publish/{statusId}/ids'.replace(
        '{statusId}',
        statusId
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getBulkUpdateJobStatus - Read Items Bulk Operations Status.
   * @param {string} statusId - status id of the bulk items operations..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getBulkUpdateJobStatus = ({ statusId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/bulkItemsOperations/{statusId}'.replace(
        '{statusId}',
        statusId
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    itemsBulkUpdate,
    getBulkUpdatePublishJobItemIds,
    getBulkUpdateJobStatus
  }
}
/** Items Search */
const itemsSearch_ = (host, authorization) => {
  /**  @function getItemsForManagement - Query Items.
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Many such query conditions can be joined using AND/OR operators and grouped with parentheses. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. In case of query across type the field names are limited to standard fields (<i>id</i>, <i>type</i>, <i>name</i>, <i>description</i>, <i>slug</i>, <i>translatable</i>, <i>language</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>, <i>repositoryId</i>, <i>status</i>, <i>channels</i>, <i>collections</i>, <i>tags</i>, <i>isPublished</i>, <i>languageIsMaster</i>, <i>taxonomies</i>). However in case of type specific query the field names are limited to standard fields and user defined fields (except fields of largeText data type). The only values allowed in the operator are <i>eq</i> (Equals), <i>co</i> (Contains), <i>sw</i> (Startswith), <i>ge</i> (Greater than or equals to), <i>le</i> (Less than or equals to), <i>gt</i> (Greater than), <i>lt</i> (Less than), <i>mt</i> (Matches), <i>sm</i> (Similar).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(name eq "John")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(type eq "Employee" AND name eq "John")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(type eq "Employee" AND ((name eq "John" AND field.age ge "40") OR fields.weight gt "70"))<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(taxonomies.categories.id eq "9E1A79EE600C4C4BB727FE3E39E95489" OR (taxonomies.categories.name co "cat" AND taxonomies.categories.name co "red"))<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(taxonomies.categories.nodes.id eq "9E1A79EE600C4C4BB727FE3E39E95489" OR taxonomies.categories.nodes.name co "cars").
   * @param {string} _default - Default search query expression, that matches values of the items across all fields..
   * @param {string} fields - This parameter is used to control the returned fields in each item in the result. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each items in the result. All the field name are case-sensitive, and users must provide the correct field name in the query. All the user-defined field names should be provided with prefix fields and followed by period (.). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard fields are returned in case of query across types and in case of type specific query, all standard and user fields are returned. This parameter is optional in the query, and by default the result shows only standard fields name, description. The standard fields <i>id</i>, <i>type</i> are always returned irrespective of any field asked. Any incorrect or invalid field name given in the query will throw an error.<br><br><b>Example</b>: This returns standard fields <i>name</i>, user fields <i>state</i> and <i>country</i> of type <i>Address</i> in the search results. <br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=fields.state,fields.country <br><br><b>Example</b>: This returns all the attributes for a specific type used in the search results.<br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=all<br><br><b>Example</b>: This returns standard fields <i>name</i>, <i>createdBy</i> in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=name,createdBy<br><br><b>Example</b>: This returns all the standard fields in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=all.
   * @param {string} repositoryId - This parameter accepts id of a repository and is used to control the returned results. The result will contain only items belonging to the specified repository. This can also be achieved by specifying the repositoryId (standard field of an item) equals query condition (<i>repositoryId eq "{repositoryId}"</i>) as one of the query conditions in the <b>q</b> query parameter. This is an optional parameter and by default returns results from all the repositories..
   * @param {string} channelToken - This parameter accepts channelToken of a channel and is used to control the returned results. The result will contain only items, targeted to the channel that the specified channelToken belongs to. This can also be achieved by specifying the channels (standard field of an item) contains query condition (<i>channels co "{channelId}"</i>) as one of the query conditions in the <b>q</b> query parameter. This is an optional parameter and by default returns all the results..
   * @param {integer} offset - This parameter accepts a non negative integer less than 10000 and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result. If offset+limit > 10000, then we treat limit as 10000-offset and gives results..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} orderBy - The orderBy parameter is used to control the order (ascending/descending) of queried items.<br/>This parameter is optional in the query and by default the results are sorted by <i>updatedDate</i> when <i>default</i> parameter is empty. When <i>default</i> parameter has value(s), the results are sorted by the relevance of <i>tags</i> of the items to the default values.<br/><br/> This parameter accepts a field name separated by a colon (:) ,for which the user wants to sort the results and sort order. <br> format : <i><b>orderBy={fieldName}:{asc/desc}</b></i> (*Note : asc stands for ascending and desc for descending. asc and desc are always in lower case.) <br> In a type-specific query, field names can be either standard fields (<i>name</i>, <i>createdDate</i>, <i>updatedDate</i>) or user-defined fields (single-valued data types (<i>number, decimal, datetime</i>). But in case of a query across types, only <i>name</i>, <i>createdDate</i> and <i>updatedDate</i> (Standard fields) are allowed. All the user-defined field names should be provided with prefix fields and followed by a period (.). <br> <b>Example</b> : <i>orderBy=name:asc</i> <br> Returns all the items in the ascending order of name.</td><br/> <b>Example</b> : <i>orderBy=updateDate:asc</i> <br>Returns all the items in the ascending order of updateDate.<br/> <b>Example</b> : <i>orderBy=fields.age:desc</i> <br>Returns all the items in the descending order of age.<br/> <b>Example</b> : <i>orderBy=fields.age</i> <br> Returns all the items in the ascending order of age..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getItemsForManagement = ({
    q,
    _default,
    fields,
    repositoryId,
    channelToken,
    offset,
    limit,
    totalResults,
    orderBy,
    links
  }) => {
    const queryParams = {
      q: q,
      default: _default,
      fields: fields,
      repositoryId: repositoryId,
      channelToken: channelToken,
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      orderBy: orderBy,
      links: links
    }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/items' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getSimilarItems - Query Similar Items.
   * @param {string} prefer - This parameter is used to control the interaction type (synchronous/asynchronous) of the request. If the header is provided with value respond-async, it indicates that asynchronous interaction is preferred. Otherwise, synchronous interaction is preferred. Asynchronous request is responded with 202 status with a status link in the location header. Synchronous request is responded with 200 along with response body..
   * @param {string} id - id of the item.(Digital Asset).
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Many such query conditions can be joined using AND/OR operators and grouped with parentheses. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. In case of query across type the field names are limited to standard fields (<i>id</i>, <i>type</i>, <i>name</i>, <i>description</i>, <i>slug</i>, <i>translatable</i>, <i>language</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>, <i>repositoryId</i>, <i>status</i>, <i>channels</i>, <i>collections</i>, <i>tags</i>, <i>isPublished</i>, <i>languageIsMaster</i>, <i>taxonomies</i>). However in case of type specific query the field names are limited to standard fields and user defined fields (except fields of largeText data type). The only values allowed in the operator are <i>eq</i> (Equals), <i>co</i> (Contains), <i>sw</i> (Startswith), <i>ge</i> (Greater than or equals to), <i>le</i> (Less than or equals to), <i>gt</i> (Greater than), <i>lt</i> (Less than), <i>mt</i> (Matches), <i>sm</i> (Similar).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(name eq "John")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(type eq "Employee" AND name eq "John")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(type eq "Employee" AND ((name eq "John" AND field.age ge "40") OR fields.weight gt "70"))<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(taxonomies.categories.id eq "9E1A79EE600C4C4BB727FE3E39E95489" OR (taxonomies.categories.name co "cat" AND taxonomies.categories.name co "red"))<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/items?q=(taxonomies.categories.nodes.id eq "9E1A79EE600C4C4BB727FE3E39E95489" OR taxonomies.categories.nodes.name co "cars").
   * @param {string} _default - Default search query expression, that matches values of the items across all fields..
   * @param {string} fields - This parameter is used to control the returned fields in each item in the result. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each items in the result. All the field name are case-sensitive, and users must provide the correct field name in the query. All the user-defined field names should be provided with prefix fields and followed by period (.). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard fields are returned in case of query across types and in case of type specific query, all standard and user fields are returned. This parameter is optional in the query, and by default the result shows only standard fields name, description. The standard fields <i>id</i>, <i>type</i> are always returned irrespective of any field asked. Any incorrect or invalid field name given in the query will throw an error.<br><br><b>Example</b>: This returns standard fields <i>name</i>, user fields <i>state</i> and <i>country</i> of type <i>Address</i> in the search results. <br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=fields.state,fields.country <br><br><b>Example</b>: This returns all the attributes for a specific type used in the search results.<br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=all<br><br><b>Example</b>: This returns standard fields <i>name</i>, <i>createdBy</i> in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=name,createdBy<br><br><b>Example</b>: This returns all the standard fields in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=all.
   * @param {string} channelToken - This parameter accepts channelToken of a channel and is used to control the returned results. The result will contain only items, targeted to the channel that the specified channelToken belongs to. This can also be achieved by specifying the channels (standard field of an item) contains query condition (<i>channels co "{channelId}"</i>) as one of the query conditions in the <b>q</b> query parameter. This is an optional parameter and by default returns all the results..
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getSimilarItems = ({
    prefer,
    id,
    q,
    _default,
    fields,
    channelToken,
    offset,
    limit,
    totalResults,
    links
  }) => {
    const queryParams = {
      q: q,
      default: _default,
      fields: fields,
      channelToken: channelToken,
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/similarItems'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      Prefer: prefer
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getSimilarItemsJobStatus - Get Similar Items Job Status.
   * @param {string} statusId - status id of similar items job..
   * @param {string} id - id of the item.(Digital Asset).
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getSimilarItemsJobStatus = ({ statusId, id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/{id}/similarItems/_status/{statusId}'
        .replace('{statusId}', statusId)
        .replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return { getItemsForManagement, getSimilarItems, getSimilarItemsJobStatus }
}
/** Items by slug */
const itemsBySlug_ = (host, authorization) => {
  /**  @function getItemBySlug - Read an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} expand - Expand parameter provides the option of getting child resources (referenced items) inline with the item's response. Accepts a comma-separated list of field names or <i>all</i>. All the user-defined field names should be provided with prefix <i>fields</i> and followed by a period (.). If these fields are of a reference type, then the resource expands their data inline in the response. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the reference type of the requested item are expanded. When expand is not specified, item response contains links to the referenced items. Expansion of this form is supported for one level only; a request to expand beyond the first level of referenced fields will produce the response HTTP 400. When the expand parameter contains a nonexistent field as per type definition of the requested item, the resource produces HTTP 400.<br><br><b>Example</b> : expand=<i>fields.field1,fields.field2</i> <br>Returns field1 and field2: names of the user-defined fields in the type to which this item belongs.<br><b>Example</b> : expand=<i>taxonomies</i> <br>Returns taxonomies field containing all categories assigned to this item.<br><b>Example</b> : expand=<i>all</i> <br>Returns all fields available for this item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} asOf - This parameter describes a specific item revision. Currently it only supports this value, <i>latestPublished</i>, which means the latest published version. The slug value passed in the url should always be that of the latest management item..
   * @param {string} asOfDate - This parameter defines a point of time as of which the item revision should be returned. The date string format is <i>yyyy-MM-dd'T'HH:mm:ss'Z'</i> or <i>yyyy-MM-dd'T'HH:mm:ss.SSS'Z'</i>.  The slug value passed in the url should always be that of the latest management item..
   */
  const getItemBySlug = ({ slug, expand, links, asOf, asOfDate }) => {
    const queryParams = {
      expand: expand,
      links: links,
      asOf: asOf,
      asOfDate: asOfDate
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemChannelsBySlug - List Channels of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemChannelsBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/channels'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemCollectionsBySlug - List Collections of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemCollectionsBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/collections'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemPublishInfoBySlug - List Publish Info of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemPublishInfoBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/publishInfo'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemPublishedChannelsBySlug - List Published Channels of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemPublishedChannelsBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/publishedChannels'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemRelationsBySlug - List Relationships of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemRelationsBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/relationships'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemTagsBySlug - List Tags of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemTagsBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/tags'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemTaxonomiesBySlug - List Taxonomies of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemTaxonomiesBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/taxonomies'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemVariationsBySlug - List Variations of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemVariationsBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/variations'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listVariationsByTypeBySlug - List all Item Variations of a Variation Type by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} variationType - Type of the variation. Possible value: <i>language</i>.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listVariationsByTypeBySlug = ({ slug, variationType, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/variations/{variationType}'
        .replace('{slug}', slug)
        .replace('{variationType}', variationType) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getMasterItemBySlug - Read master of an Item Variation set by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} variationType - Type of the variation. Possible value: <i>language</i>.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getMasterItemBySlug = ({ slug, variationType, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/variations/{variationType}/master'
        .replace('{slug}', slug)
        .replace('{variationType}', variationType) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getItemForVariationBySlug - Read Item Variation of a Variation Type Value by slug.
   * @param {string} channelToken - Channel token of the target channel..
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} variationType - Type of the variation. Possible value: <i>language</i>.
   * @param {string} variationValue - Value of the variation type. Example: <i>en-US</i>, <i>fr</i> etc..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getItemForVariationBySlug = ({
    channelToken,
    slug,
    variationType,
    variationValue,
    links
  }) => {
    const queryParams = { channelToken: channelToken, links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/variations/{variationType}/{variationValue}'
        .replace('{slug}', slug)
        .replace('{variationType}', variationType)
        .replace('{variationValue}', variationValue) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listItemVersionInfoBySlug - List Version Info of an Item by slug.
   * @param {string} slug - Slug value of the latest management Item..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listItemVersionInfoBySlug = ({ slug, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/items/.by.slug/{slug}/versionInfo'.replace(
        '{slug}',
        slug
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    getItemBySlug,
    listItemChannelsBySlug,
    listItemCollectionsBySlug,
    listItemPublishInfoBySlug,
    listItemPublishedChannelsBySlug,
    listItemRelationsBySlug,
    listItemTagsBySlug,
    listItemTaxonomiesBySlug,
    listItemVariationsBySlug,
    listVariationsByTypeBySlug,
    getMasterItemBySlug,
    getItemForVariationBySlug,
    listItemVersionInfoBySlug
  }
}
/** Languages */
const languages_ = (host, authorization) => {
  /**  @function getDisplayLanguages - Read Language.
   * @param {string} inLanguage - Language in which results are localized.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getDisplayLanguages = ({ inLanguage, links }) => {
    const queryParams = { inLanguage: inLanguage, links: links }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/languageCodes' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return { getDisplayLanguages }
}
/** Localization Policies */
const localizationPolicies_ = (host, authorization) => {
  /**  @function listLocalizationPolicies - List All Localization Policies.
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - This parameter is used to control order of results. The value of this query parameter follow the format of <i> fieldName:[asc/desc]</i>. <i>asc</i> stands for ascending order  <i>desc</i> stands for descending order, default order is <i>asc</i>. The only fields allowed in the field name are <b>name</b> and <b>updatedDate</b>..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>name</b></i> and <i><b>connectorType</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on <i><b>connectorType</b></i>. This query param is optional with no default.<br><b>Example</b>:<br> ?q=name co "foo")<br><b>Example</b>:<br> ?q=connectorType eq "translation")<br><b>Example</b>:<br> ?q=connectorType eq "content").
   */
  const listLocalizationPolicies = ({
    offset,
    limit,
    orderBy,
    totalResults,
    links,
    q
  }) => {
    const queryParams = {
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links,
      q: q
    }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/localizationPolicies' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createLocalizationPolicy - Create a Localization Policy.
   * @param {undefined} body - Creates a localization policy with the given information in the payload. The fields <i>id, createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createLocalizationPolicy = ({ body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/localizationPolicies' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getPolicy - Read a Localization Policy.
   * @param {string} id - Localization Policy id.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getPolicy = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/localizationPolicies/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updatePolicy - Update a Localization Policy.
   * @param {string} id - Localization Policy id.
   * @param {undefined} body - Updates a localization policy with the given information in the payload. The fields <i>createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updatePolicy = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/localizationPolicies/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deletePolicy - Delete a Localization Policy.
   * @param {string} id - Localization Policy id.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deletePolicy = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/localizationPolicies/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    listLocalizationPolicies,
    createLocalizationPolicy,
    getPolicy,
    updatePolicy,
    deletePolicy
  }
}
/** OAuth Tokens */
const oAuthTokens_ = (host, authorization) => {
  /**  @function createToken - Generate an OAuth Token.
   * @param {string} id - Generates an OAuth token for the given channelId.
   * @param {undefined} body - Channel Secret of the channel to generate OAuth Token.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createToken = ({ id, body, xRequestedWith }) => {
    // consumes  UNKOWN
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = ''
    const path =
      '/content/management/api/v1.1/channels/{id}/oauthToken'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return { createToken }
}
/** Permission Operations */
const permissionOperations_ = (host, authorization) => {
  /**  @function executePermissionOperations - Performs Permission Operations on resource.
   * @param {undefined} body - Details of the permission operations..
   * @param {string} prefer - This parameter is used to control the interaction type (synchronous/asynchronous) of the request. If the header is provided with value respond-async, it indicates that asynchronous interaction is preferred. Otherwise, synchronous interaction is preferred. Asynchronous request is responded with 202 status with a status link in the location header. Synchronous request is responded with 200 along with response body..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const executePermissionOperations = ({
    body,
    prefer,
    links,
    xRequestedWith
  }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/permissionOperations' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      Prefer: prefer,
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getPermissionOperationsStatus - Read Permission Operations Status.
   * @param {string} statusId - status id of the permission operations..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getPermissionOperationsStatus = ({ statusId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/permissionOperations/{statusId}'.replace(
        '{statusId}',
        statusId
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return { executePermissionOperations, getPermissionOperationsStatus }
}
/** Recommendations */
const recommendations_ = (host, authorization) => {
  /**  @function getAudienceAttributes - List all Audience Attributes..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>name</i> and <i>categoryId</i> The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/properties?q=(categoryId eq "AWVF3H79KJ2312VB0")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/properties?q=(name eq "Some property").
   * @param {string} _default - Default search query expression..
   * @param {string} fields - This parameter is used to control the returned fields for a audience attribute. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each property in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each audience attribute has both standard fields (<i>id</i>, <i>name</i>, <i>description</i> and <i>categoryId</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each audience attribute. <br> .
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - Order by results..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getAudienceAttributes = ({
    q,
    _default,
    fields,
    offset,
    limit,
    orderBy,
    totalResults,
    links
  }) => {
    const queryParams = {
      q: q,
      default: _default,
      fields: fields,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/audienceAttributes' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createAudienceAttribute - Create an Audience Attributes..
   * @param {undefined} body - Create a audience attributes with the given information in the payload. The fields <i>id</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createAudienceAttribute = ({ body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/audienceAttributes' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getAudienceAttribute - Read a specific audience attributes by id..
   * @param {string} id - Id of the audience attributes..
   * @param {string} fields - This parameter is used to control the returned fields for a audience attribute. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each property in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each audience attribute has both standard fields (<i>id</i>, <i>name</i>, <i>description</i> and <i>categoryId</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each audience attribute. <br> .
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getAudienceAttribute = ({ id, fields, links }) => {
    const queryParams = { fields: fields, links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/audienceAttributes/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateAudienceAttribute - Update an Audience Attribute..
   * @param {string} id - Id of the audience attributes..
   * @param {undefined} body - Update an Audience Attribute with the given information in the payload. .
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateAudienceAttribute = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/audienceAttributes/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteAudienceAttributeById - Delete an audience attribute by id..
   * @param {string} id - Id of the audience attributes..
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteAudienceAttributeById = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/personalization/audienceAttributes/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getCategories - This resource returns a list of available attribute categories..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>name</i> and <i>type</i>When listing categories, <i>type</i> can be equal to "standard", "custom" or "all". If <i>type</i> is equals to "all", all categories will be retrieved. The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/categories?q=(type eq "custom")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/categories?q=(name eq "Some space").
   * @param {string} _default - Default search query expression..
   * @param {string} fields - This parameter is used to control the returned fields for a attribute category. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each category in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each recommendation has both standard fields (<i>id</i>, <i>name</i>, <i>description</i> and <i>type</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each category. <br> .
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - Order by results..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getCategories = ({
    q,
    _default,
    fields,
    offset,
    limit,
    orderBy,
    totalResults,
    links
  }) => {
    const queryParams = {
      q: q,
      default: _default,
      fields: fields,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/personalization/categories' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getCategory - Read a specific category by id..
   * @param {string} id - Id of the category..
   * @param {string} fields - This parameter is used to control the returned fields for a attribute category. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each category in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each recommendation has both standard fields (<i>id</i>, <i>name</i>, <i>description</i> and <i>type</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each category. <br> .
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getCategory = ({ id, fields, links }) => {
    const queryParams = { fields: fields, links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/categories/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function testRecommendation - Obtain the results from the recommendation..
* @param {string} apiName - API name of the recommendation..
* @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field name allowed is <i>repositoryId</i>. The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(apiName eq "TestRecommendation")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(repositoryId eq "EAQWER42DGKJ10PCNMGAE").
* @param {undefined} body - Array of audience attribute name value pairs.  These will be used as input to the recommendation. <br/><br/>Attribute entries are of the form "\<category\>.\<audienceAttribute\>" : "\<value\>" <br/><br/><b>NOTE:</b> Audience attribute value pairs specified in the query will override audience attriobutes specified in the body..
* @param {array} attributeCategoryAttributeName - List of audience attributes. The audience attributes should be prefixed with the keyword <b>attribute</b>: <br/><br/><b><i>attribute.\<category\>.\<audienceAttribute\>=\<value\></i></b><br/><br/><b>Example:</b>  <i>?attribute.custom.myAttribute1=value1&attribute.custom.myAttribute2=value2</i><br/><br/><br/><br/>Where multivalued audience attributes are allowed, they can be provided in the query by repeating the name value pairs. <br/><br/><b>Example:</b>  <i>?attribute.custom.myMultiValue=value1&attribute.custom.myMultiValue=value2</i> etc.<br/><br/>
.
* @param {string} fields - This parameter is used to control the returned fields in each item in the result. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each items in the result. All the field name are case-sensitive, and users must provide the correct field name in the query. All the user-defined field names should be provided with prefix fields and followed by period (.). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard fields are returned in case of query across types and in case of type specific query, all standard and user fields are returned. This parameter is optional in the query, and by default the result shows only standard fields name, description. The standard fields <i>id</i>, <i>type</i> are always returned irrespective of any field asked. Any incorrect or invalid field name given in the query will throw an error.<br><br><b>Example</b>: This returns standard fields <i>name</i>, user fields <i>state</i> and <i>country</i> of type <i>Address</i> in the search results. <br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=fields.state,fields.country <br><br><b>Example</b>: This returns all the attributes for a specific type used in the search results.<br>https://{cecsdomain}/content/management/api/v1.1/items?q=type eq "Address"&fields=all<br><br><b>Example</b>: This returns standard fields <i>name</i>, <i>createdBy</i> in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=name,createdBy<br><br><b>Example</b>: This returns all the standard fields in the search results for all items across all the types. <br>https://{cecsdomain}/content/management/api/v1.1/items?fields=all.
* @param {string} channelToken - Channel token to use to test the recommendation against. If no channel is provided, the recommendation will run against all assets in the current repository and not only assets published to or targeted for a specific channel..
* @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
* @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
* @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
* @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
* @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
*/
  const testRecommendation = ({
    apiName,
    q,
    body,
    attributeCategoryAttributeName,
    fields,
    channelToken,
    offset,
    limit,
    totalResults,
    links,
    xRequestedWith
  }) => {
    const queryParams = {
      q: q,
      'attribute.category.attributeName': attributeCategoryAttributeName,
      fields: fields,
      channelToken: channelToken,
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      links: links
    }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendationResults/{apiName}'.replace(
        '{apiName}',
        apiName
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getRecommendations - List all recommendations.
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field name allowed is <i>repositoryId</i>. The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(apiName eq "TestRecommendation")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(repositoryId eq "EAQWER42DGKJ10PCNMGAE").
   * @param {string} _default - Default search query expression..
   * @param {string} fields - This parameter is used to control the returned fields for a recommendation. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each recommendation in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each recommendation has both standard fields (<i>id</i>, <i>name</i>, <i>apiName</i>, <i>description</i>, <i>createdBy</i>, <i>createdAt</i>, <i>updatedBy</i>, <i>updatedAt</i>, <i>main</i> and <i>defaults</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each recommendation. <br> .
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - Order by results. Recommendations can currently only be ordered by name..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getRecommendations = ({
    q,
    _default,
    fields,
    offset,
    limit,
    orderBy,
    totalResults,
    links
  }) => {
    const queryParams = {
      q: q,
      default: _default,
      fields: fields,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createRecommendation - Create a new Recommendation..
   * @param {undefined} body - Create a Recommendation with the given information in the payload. The fields <i>id, status, isPublished, createdBy, createdAt, updatedBy, updatedAt</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createRecommendation = ({ body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getRecommendation - Read a specific Recommendation by id..
   * @param {string} id - Id of the Recommendation..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field name allowed is <i>repositoryId</i>. The only value allowed in the operator is <i>eq</i> (Equals).<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(apiName eq "TestRecommendation")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/personalization/recommendations?q=(repositoryId eq "EAQWER42DGKJ10PCNMGAE").
   * @param {string} fields - This parameter is used to control the returned fields for a recommendation. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each recommendation in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each recommendation has both standard fields (<i>id</i>, <i>name</i>, <i>apiName</i>, <i>description</i>, <i>createdBy</i>, <i>createdAt</i>, <i>updatedBy</i>, <i>updatedAt</i>, <i>main</i> and <i>defaults</i>. When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each recommendation. <br> .
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getRecommendation = ({ id, q, fields, links }) => {
    const queryParams = { q: q, fields: fields, links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateRecommendation - Update a Recommendation..
   * @param {string} id - Id of the Recommendation..
   * @param {undefined} body - Update a Recommendation with the given information in the payload. .
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateRecommendation = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteRecommendationById - Delete a Recommendation..
   * @param {string} id - Id of the Recommendation..
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteRecommendationById = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function approveRecommendation - Approve or reject a recommendation..
   * @param {string} id - Id of the Recommendation..
   * @param {undefined} body - The information to approve or reject a Recommendation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const approveRecommendation = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/approve'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function publishRecommendation - Publish a Recommendation..
   * @param {string} id - Id of the Recommendation..
   * @param {undefined} body - The information needed to publish a Recommendation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const publishRecommendation = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/publish'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getPublishJobStatus - Read publish job status..
   * @param {string} id - Id of the Recommendation..
   * @param {string} statusId - Status id of the Recommendation publish operation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getPublishJobStatus = ({ id, statusId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/publish/{statusId}'
        .replace('{id}', id)
        .replace('{statusId}', statusId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getRecommendationPublishJobItemIds - Read the Recommendation's published Item ids.
   * @param {string} id - Id of the Recommendation..
   * @param {string} statusId - Status id of the Recommendation publish operation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   */
  const getRecommendationPublishJobItemIds = ({
    id,
    statusId,
    links,
    offset,
    limit,
    totalResults
  }) => {
    const queryParams = {
      links: links,
      offset: offset,
      limit: limit,
      totalResults: totalResults
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/publish/{statusId}/ids'
        .replace('{id}', id)
        .replace('{statusId}', statusId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function submitRecommendation - Submit a recommendation for approval..
   * @param {string} id - Id of the Recommendation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const submitRecommendation = ({ id, links, xRequestedWith }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/submitForApproval'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function unpublishRecommendation - Unpublish a Recommendation..
   * @param {string} id - Id of the Recommendation..
   * @param {undefined} body - The information needed to unpublish a Recommendation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const unpublishRecommendation = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/unpublish'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getUnpublishJobStatus - Read unpublish job status..
   * @param {string} id - Id of the Recommendation..
   * @param {string} statusId - Status id of the Recommendation publish operation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getUnpublishJobStatus = ({ id, statusId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/unpublish/{statusId}'
        .replace('{id}', id)
        .replace('{statusId}', statusId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getRecommendationUnpublishJobItemIds - Read the Recommendation's unpublished Item ids.
   * @param {string} id - Id of the Recommendation..
   * @param {string} statusId - Status id of the Recommendation publish operation..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   */
  const getRecommendationUnpublishJobItemIds = ({
    id,
    statusId,
    links,
    offset,
    limit,
    totalResults
  }) => {
    const queryParams = {
      links: links,
      offset: offset,
      limit: limit,
      totalResults: totalResults
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/unpublish/{statusId}/ids'
        .replace('{id}', id)
        .replace('{statusId}', statusId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function validateRecommendation - Validate a recommendation..
   * @param {string} id - Id of the Recommendation..
   * @param {undefined} body - The information to validate a Recommendation and its default items for publishing to the provided channel(s).  If no channels are provided, the targeted channels in the recommendation is used..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const validateRecommendation = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/personalization/recommendations/{id}/validatePublish'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    getAudienceAttributes,
    createAudienceAttribute,
    getAudienceAttribute,
    updateAudienceAttribute,
    deleteAudienceAttributeById,
    getCategories,
    getCategory,
    testRecommendation,
    getRecommendations,
    createRecommendation,
    getRecommendation,
    updateRecommendation,
    deleteRecommendationById,
    approveRecommendation,
    publishRecommendation,
    getPublishJobStatus,
    getRecommendationPublishJobItemIds,
    submitRecommendation,
    unpublishRecommendation,
    getUnpublishJobStatus,
    getRecommendationUnpublishJobItemIds,
    validateRecommendation
  }
}
/** Repositories */
const repositories_ = (host, authorization) => {
  /**  @function listRepositories - List All Repositories.
   * @param {string} roleName - This parameter is used to filter the returned repositories with the given role name..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>roleName</b></i>, <i><b>repositoryId</b></i> and <i><b>name</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on the others. This query param is optional and defaults to <i><b>roleName eq "viewer"</b></i> which filters the resources with at least given role. <i><b>name</b></i> is interpreted in the context of the resource being requested. For eg. name for content types implies content type name.<br><b>Example</b>:<br> ?q=roleName eq "manager").
   * @param {string} fields - This parameter is used to control the returned fields in each repository in the list. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each repository in the list. All the field names are case-sensitive, users must provide the correct field names in the query. Each repository has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>) and additional fields (<i>contentTypes</i>, <i>channels</i>, <i>defaultLanguage</i>, <i>languageOptions</i>)' When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. The user can filter out only the additional fields. This parameter is optional in the query, and by default the result shows only standard fields in the response. Any incorrect or invalid field name given in the query will throw an error. <br><br> <b>Example</b>: <i>?fields=contentTypes,channels</i> <br> This returns all standard fields along with the <i>contentTypes</i> and <i>channels</i> additional fields for each repository.<br> <b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each repository. <br> .
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - This parameter is used to control order of results. The value of this query parameter follow the format of <i> fieldName:[asc/desc]</i>. <i>asc</i> stands for ascending order  <i>desc</i> stands for descending order, default order is <i>asc</i>.The only fields allowed in the field name are <b>name</b> and <b>updatedDate</b>..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const listRepositories = ({
    roleName,
    q,
    fields,
    offset,
    limit,
    orderBy,
    totalResults,
    links
  }) => {
    const queryParams = {
      roleName: roleName,
      q: q,
      fields: fields,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/repositories' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createRepository - Create a Repository.
   * @param {undefined} body - Creates a repository with the given information in the payload. The fields <i>id, createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createRepository = ({ body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/repositories' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getRepository - Read a Repository.
   * @param {string} id - id of the repository..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getRepository = ({ id, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/repositories/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateRepository - Update a Repository.
   * @param {string} id - id of the repository..
   * @param {undefined} body - Updates a repository with the given information in the payload. The fields <i>createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateRepository = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/repositories/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteRepository - Delete a Repository.
   * @param {string} id - id of the repository..
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteRepository = ({ id, xRequestedWith }) => {
    const qs = ''
    const path =
      '/content/management/api/v1.1/repositories/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listRepositoryPermissions - List All Permissions on a Repository.
   * @param {string} id - id of the repository..
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const listRepositoryPermissions = ({
    id,
    offset,
    limit,
    totalResults,
    links
  }) => {
    const queryParams = {
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/repositories/{id}/permissions'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    listRepositories,
    createRepository,
    getRepository,
    updateRepository,
    deleteRepository,
    listRepositoryPermissions
  }
}
/** Taxonomies */
const taxonomies_ = (host, authorization) => {
  /**  @function getTaxonomies - List taxonomies.
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>status</i> and <i>version</i>. A query cannot include multiple <i>status</i> or <i>version</i> fieldNames. If no value is provided for <i>status</i> it defaults to "promoted". When listing taxonomies, <i>status</i> can be equals to "draft", "promoted" or "all". If <i>status</i> is equals to "all", all taxonomies will be retrieved - if a taxonomy is currently available in both "draft" and "promoted" states, only "draft" will be returned. In case <i>status</i> equals to "all" is used in other endpoints, an error will be returned. The field <i>version</i> is currently ignored.   The only value allowed in the operator is <i>eq</i> (Equals).<br><br>When updating a taxonomy the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted taxonomy cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "promoted").
   * @param {string} _default - Default search query expression..
   * @param {string} fields - This parameter is used to control the returned fields for a taxonomy. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each taxonomy in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each taxonomy has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>shortName</i>, <i>status</i>, <i>version</i>, <i>isPublishable</i>, <i>customProperties</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>) and additional fields (<i>availableStates</i> and <i>publishedChannels</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Taxonomy in "draft" state will not have a <i>version</i>. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in error. <br><br> This returns all standard fields along with the additional field <i>availableStates</i> for each taxonomy.<br><b>Example</b>: <i>?fields=availableStates</i> <br><br> This returns all standard fields along with the additional fields <i>availableStates</i> and <i>publishedChannels</i> for each taxonomy.<br><b>Example</b>: <i>?fields=availableStates,publishedChannels</i> <br><br> This returns all standard fields along with all additional fields (<i>availableStates</i> and <i>publishedChannels</i>) for each taxonomy.<br> <b>Example</b>: <i>?fields=all</i> <br> .
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - Order by results..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getTaxonomies = ({
    q,
    _default,
    fields,
    offset,
    limit,
    orderBy,
    totalResults,
    links
  }) => {
    const queryParams = {
      q: q,
      default: _default,
      fields: fields,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/taxonomies' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createTaxonomy - Create a taxonomy.
   * @param {undefined} body - Creates a taxonomy with the given information in the payload. The fields id, createdBy, createdDate, updatedBy, updatedDate, status, version, availableStates, publishedChannels and links will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createTaxonomy = ({ body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/taxonomies' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getTaxonomy - Read a taxonomy.
   * @param {string} id - id of the taxonomy..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>status</i> and <i>version</i>. A query cannot include multiple <i>status</i> or <i>version</i> fieldNames. If no value is provided for <i>status</i> it defaults to "promoted". When listing taxonomies, <i>status</i> can be equals to "draft", "promoted" or "all". If <i>status</i> is equals to "all", all taxonomies will be retrieved - if a taxonomy is currently available in both "draft" and "promoted" states, only "draft" will be returned. In case <i>status</i> equals to "all" is used in other endpoints, an error will be returned. The field <i>version</i> is currently ignored.   The only value allowed in the operator is <i>eq</i> (Equals).<br><br>When updating a taxonomy the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted taxonomy cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "promoted").
   * @param {string} fields - This parameter is used to control the returned fields for a taxonomy. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each taxonomy in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each taxonomy has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>shortName</i>, <i>status</i>, <i>version</i>, <i>isPublishable</i>, <i>customProperties</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>) and additional fields (<i>availableStates</i> and <i>publishedChannels</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Taxonomy in "draft" state will not have a <i>version</i>. Users can only filter out the additional fields. This parameter is optional in the query and by default result shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in error. <br><br> This returns all standard fields along with the additional field <i>availableStates</i> for each taxonomy.<br><b>Example</b>: <i>?fields=availableStates</i> <br><br> This returns all standard fields along with the additional fields <i>availableStates</i> and <i>publishedChannels</i> for each taxonomy.<br><b>Example</b>: <i>?fields=availableStates,publishedChannels</i> <br><br> This returns all standard fields along with all additional fields (<i>availableStates</i> and <i>publishedChannels</i>) for each taxonomy.<br> <b>Example</b>: <i>?fields=all</i> <br> .
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getTaxonomy = ({ id, q, fields, links }) => {
    const queryParams = { q: q, fields: fields, links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateTaxonomy - Update a taxonomy.
   * @param {string} id - id of the taxonomy..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>status</i> and <i>version</i>. A query cannot include multiple <i>status</i> or <i>version</i> fieldNames. If no value is provided for <i>status</i> it defaults to "promoted". When listing taxonomies, <i>status</i> can be equals to "draft", "promoted" or "all". If <i>status</i> is equals to "all", all taxonomies will be retrieved - if a taxonomy is currently available in both "draft" and "promoted" states, only "draft" will be returned. In case <i>status</i> equals to "all" is used in other endpoints, an error will be returned. The field <i>version</i> is currently ignored.   The only value allowed in the operator is <i>eq</i> (Equals).<br><br>When updating a taxonomy the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted taxonomy cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "promoted").
   * @param {undefined} body - Update a taxonomy with the given information in the payload. The fields <i>id, status, version, availableStates, publishedChannels, createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i> will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateTaxonomy = ({ id, q, body, links, xRequestedWith }) => {
    const queryParams = { q: q, links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteTaxonomyById - Delete a taxonomy.
   * @param {string} id - id of the taxonomy..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Query conditions can be joined using AND operators and grouped with parentheses. The value of a query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names allowed are <i>status</i> and <i>version</i>. A query cannot include multiple <i>status</i> or <i>version</i> fieldNames. If no value is provided for <i>status</i> it defaults to "promoted". When listing taxonomies, <i>status</i> can be equals to "draft", "promoted" or "all". If <i>status</i> is equals to "all", all taxonomies will be retrieved - if a taxonomy is currently available in both "draft" and "promoted" states, only "draft" will be returned. In case <i>status</i> equals to "all" is used in other endpoints, an error will be returned. The field <i>version</i> is currently ignored.   The only value allowed in the operator is <i>eq</i> (Equals).<br><br>When updating a taxonomy the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted taxonomy cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies?q=(status eq "promoted").
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteTaxonomyById = ({ id, q, xRequestedWith }) => {
    const queryParams = { q: q }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}'.replace('{id}', id) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getCategories_1 - Search categories.
   * @param {string} id - id of the taxonomy..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Many query conditions can be joined using AND/OR operators and grouped with parentheses. The value of the query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i><br/><br/>The only field names supported are <i>status</i>, <i>parent.id</i>, <i>parentId</i>, <i>id</i>, <i>name</i>, and <i>apiName</i>. If no value is provided for <i>status</i> it defaults to "promoted".  The field <i>parentId</td> is a legacy field from the database search and is interchangeable with <i>parent.id</i>.<br><br>When a <i>parentId</i> or <i>parent.id</i> is provided, only categories with that parent id will be listed.  If no <i>parentId</i> is provided, categories from all levels will be returned in the list.<br><br>When a <i>id</i> is provided, categories matching the criteria with be returned.  The valid operator is <i>eq</i>.<br><br>When a <i>name</i> is provided, categories matching the criteria with be returned.  The valid operators are <i>eq</i>, <i>sw</i>, and <i>co</i>.<br><br>When an <i>apiName</i> is provided, categories matching the criteria with be returned.  The valid operator is <i>eq</i>.<br><br>When updating a category the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted category cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted" and parent.id eq "DJGSAFWEGSSADWDFEWG235F")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted" and id eq "DJGSAFWEGSSADWDFEWG235F")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted" and name sw "car")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted" and apiName eq "AAAA").
   * @param {string} fields - The fields parameter is used to control the returned fields and values in the queried category. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each queried category. As all the field names are case-sensitive, users must provide the correct field names in the search query. When fields is specified as <i>all</i> (in lower case), all the standard fields and optional fields are returned for each category. Each category has both standard fields (<i>id</i>, <i>name</i>, <i>apiName</i>, <i>description</i>, <i>parent</i>, <i>parentId</i>, <i>position</i>, <i>status</i>) and optional fields (<i>ancestors</i>). The standard field <i>id</i> is always returned in the response and cannot be filtered out. This parameter is optional in the query and by default query result shows only <i>id</i>, <i>name</i>, <i>description</i>, <i>apiName</i>, <i>status</i>, <i>position</i>, <i>parentId</i> in the response. Any incorrect or invalid field name given will result in an error. <br><br> <b>Example</b>: <i>?q=(name co "car")&fields=name,description,parent,ancestors</i> <br> This returns <i>id</i>, <i>name</i>, <i>description</i>, <i>parent</i> and <i>ancestors</i> in the search results for a category containing "car" in the <i>name</i> field. <br> <b>Example</b>: <i>?fields=name,parent</i> <br> This will return only standard fields (such as <i>id</i>, <i>name</i> and <i>parent</i>) for all categories within the default limit. <br>.
   * @param {string} _default - Default search query expression..
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - This parameter is used to control order of results. The value of this query parameter follow the format of fieldName:[asc/desc]. asc stands for ascending order desc stands for descending order. <br/><br/>Allowed fields are <i>name</i> and <i>position</i>. The default sort order is <i>asc</i>..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const getCategories_1 = ({
    id,
    q,
    fields,
    _default,
    offset,
    limit,
    orderBy,
    totalResults,
    links
  }) => {
    const queryParams = {
      q: q,
      fields: fields,
      default: _default,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/categories'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createCategory - Create a category.
   * @param {string} id - id of the taxonomy..
   * @param {undefined} body - Creates a category with the given information in the payload. The fields <i>id, children, idPath, namePath</i> and <i>links</i> will be ignored even if given in the payload.<br><br>The <i>parentId</i> when provided will attach the category to the category with that id. To create a 1st level category, the <i>parentId</i> should be set to the taxonomy <i>id</i>.  The <i>parentId</i> cannot be empty when creating a category.<br><br>The <i>position</i> field can be used to specify the order of the category among its siblings. If no <i>position</i> is provided the category will be placed last among its siblings.<br><br>The <i>apiName</i> field can be used to uniquely identify the category across all taxonomies..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createCategory = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/categories'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getCategory_1 - Read a category.
   * @param {string} id - id of the taxonomy..
   * @param {string} categoryId - Unique identifier (id) for a category..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. Many query conditions can be joined using AND/OR operators and grouped with parentheses. The value of the query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only field names supported are <i>status</i> and <i>version</i>. If no value is provided for <i>status</i> it defaults to "promoted". The field <i>version</i> is currently ignored.  The only value allowed in the operator is <i>eq</i> (Equals).  <br><br>When updating a category the query parameter should always be provided with status set to "draft" as the default status is "promoted" and a promoted category cannot be modified.<br><br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "draft")<br><b>Example</b>:<br> https://{cecsdomain}/content/management/api/v1.1/taxonomies/{id}/categories?q=(status eq "promoted").
   * @param {string} _default - Default search query expression..
   * @param {string} fields - This parameter is used to control the returned fields for a category. This parameter accepts a comma-separated list of field names or <i>all</i>. These fields will be returned for each category in the list. As all the field names are case-sensitive, users must provide the correct field names in the query. Each category has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>position</i>, <i>parentId</i>) and additional fields (<i>namePath</i>, <i>idPath</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. Users can only filter out the additional fields. This parameter is optional in the query and by default results shows only standard fields in the response. Any incorrect or invalid field name given in the query will result in an error. <br><br><b>Example</b>: <i>?fields=namePath</i> <br> This returns all standard fields along with the <i>namedPath</i> additional field for the category.<br> <b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for the category. <br> .
   * @param {string} expand - Expand parameter provides the option of getting child resources (referenced items) inline with the category's response. Accepts a comma-separated list of field names or <i>all</i>. Field names are case-sensitive. When expand is specified as <i><b>all</b></i> (with <i>all</i> in lower case), all the fields of the requested category are expanded. When expand is not specified, the category response contains links to the referenced children. Expansion of this form is supported for one level only. When the expand parameter contains a nonexistent field as per category definition, the resource produces HTTP 400.<br><br><b>Example</b> : expand=<i>children</i> <br>Returns children categories sorted by their respective <i>position</i> ascending. This sort order cannot be changed in this request.<br><b>Example</b> : expand=<i>all</i> <br>Returns child resources (<i>children</i>) available for this category. Only the first 1000 children categories will be expanded..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getCategory_1 = ({
    id,
    categoryId,
    q,
    _default,
    fields,
    expand,
    links
  }) => {
    const queryParams = {
      q: q,
      default: _default,
      fields: fields,
      expand: expand,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/categories/{categoryId}'
        .replace('{id}', id)
        .replace('{categoryId}', categoryId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateCategory - Update a category.
   * @param {string} id - id of the taxonomy..
   * @param {string} categoryId - Unique identifier (id) for a category..
   * @param {string} q - Query expression..
   * @param {undefined} body - Updates a category with the given information in the payload. The fields <i>id, children, idPath, namePath</i> and <i>links</i> will be ignored even if given in the payload.<br><br>The <i>parentId</i> when provided can be used to move the category and the tree below it to another parent category in the taxonomy. If the <i>parentId</i> is not provided, the category location is not affected. <br><br>The <i>position</i> field can be used to specify the order of the category among its siblings. If no <i>position</i> is provided the category will retain its current position.<br><br>The <i>apiName</i> field can be used to uniquely identify the category across all taxonomies..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateCategory = ({
    id,
    categoryId,
    q,
    body,
    links,
    xRequestedWith
  }) => {
    const queryParams = { q: q, links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/categories/{categoryId}'
        .replace('{id}', id)
        .replace('{categoryId}', categoryId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteCategory - Delete a category.
   * @param {string} id - id of the taxonomy..
   * @param {string} categoryId - Unique identifier (id) for a category..
   * @param {string} q - Query expression..
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteCategory = ({ id, categoryId, q, xRequestedWith }) => {
    const queryParams = { q: q }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/categories/{categoryId}'
        .replace('{id}', id)
        .replace('{categoryId}', categoryId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function copyCategory - Copy a category.
   * @param {string} id - id of the taxonomy..
   * @param {string} categoryId - Unique identifier (id) for a category..
   * @param {undefined} body - Category copy request payload. The <i>status</i> and <i>version</i> will be used to determine the source taxonomy. Currently, the <i>status</i> and <i>version</i> are not used because copy is supported only on <i><b>draft</b></i> taxonomies.The <i>targetParentId</i> is the parent category for the newly created copy. The <i>targetPosition</i> will be the position of the copy category among its new siblings. This is an asynchronous operation. Asynchronous request is responded with 202 status with a status link in the location header..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const copyCategory = ({ id, categoryId, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/categories/{categoryId}/copy'
        .replace('{id}', id)
        .replace('{categoryId}', categoryId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getCopyCategoryJobStatus - Read copy category status.
   * @param {string} id - id of the taxonomy..
   * @param {string} categoryId - Unique identifier (id) for a category..
   * @param {string} jobTokenId - id for the job..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getCopyCategoryJobStatus = ({ id, categoryId, jobTokenId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/categories/{categoryId}/copy/{jobTokenId}'
        .replace('{id}', id)
        .replace('{categoryId}', categoryId)
        .replace('{jobTokenId}', jobTokenId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createDraftTaxonomy - Create a new draft version.
   * @param {string} id - id of the taxonomy..
   * @param {undefined} body - Taxonomy create draft request payload. The <i>status</i> and <i>version</i> will be used to determine the source taxonomy.  Currently, the <i>version</i> is not used. This is an asynchronous operation. Asynchronous request is responded with 202 status with a status link in the location header..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createDraftTaxonomy = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes  UNKOWN
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/createDraft'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getCreateDraftJobStatus - Read draft creation status.
   * @param {string} id - id of the taxonomy..
   * @param {string} jobTokenId - id for the job..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getCreateDraftJobStatus = ({ id, jobTokenId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/createDraft/{jobTokenId}'
        .replace('{id}', id)
        .replace('{jobTokenId}', jobTokenId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function promoteTaxonomy - Promote a taxonomy.
   * @param {string} id - id of the taxonomy..
   * @param {undefined} body - Taxonomy promote request payload.  Currently, only <i><b>draft</b></i> taxonomies can be promoted and thus the payload is ignored. This is an asynchronous operation. Asynchronous request is responded with 202 status with a status link in the location header..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const promoteTaxonomy = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes  UNKOWN
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/promote'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getPromoteJobStatus - Read promote status.
   * @param {string} id - id of the taxonomy..
   * @param {string} jobTokenId - id for the job..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getPromoteJobStatus = ({ id, jobTokenId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/promote/{jobTokenId}'
        .replace('{id}', id)
        .replace('{jobTokenId}', jobTokenId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function publishTaxonomy - Publish a taxonomy.
   * @param {string} id - id of the taxonomy..
   * @param {undefined} body - Taxonomy publishing request payload. Currently, only <i><b>promoted</b></i> taxonomies can be published and thus the <i>status</i> and the <i>version</i> are not used. This is an asynchronous operation. Asynchronous request is responded with 202 status with a status link in the location header..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const publishTaxonomy = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes  UNKOWN
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/publish'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getPublishJobStatus_1 - Read publish job status.
   * @param {string} id - id of the taxonomy..
   * @param {string} jobTokenId - id for the job..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getPublishJobStatus_1 = ({ id, jobTokenId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/publish/{jobTokenId}'
        .replace('{id}', id)
        .replace('{jobTokenId}', jobTokenId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function unpublishTaxonomy - Unpublish a taxonomy.
   * @param {string} id - id of the taxonomy..
   * @param {undefined} body - Taxonomy unpublishing request payload. Currently, only <i><b>published</b></i> taxonomies can be unpublished and thus the <i>status</i> and the <i>version</i> are not used. This is an asynchronous operation. Asynchronous request is responded with 202 status with a status link in the location header..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const unpublishTaxonomy = ({ id, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes  UNKOWN
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/unpublish'.replace(
        '{id}',
        id
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getUnpublishJobStatus_1 - Read unpublish status.
   * @param {string} id - id of the taxonomy..
   * @param {string} jobTokenId - id for the job..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getUnpublishJobStatus_1 = ({ id, jobTokenId, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/taxonomies/{id}/unpublish/{jobTokenId}'
        .replace('{id}', id)
        .replace('{jobTokenId}', jobTokenId) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    getTaxonomies,
    createTaxonomy,
    getTaxonomy,
    updateTaxonomy,
    deleteTaxonomyById,
    getCategories_1,
    createCategory,
    getCategory_1,
    updateCategory,
    deleteCategory,
    copyCategory,
    getCopyCategoryJobStatus,
    createDraftTaxonomy,
    getCreateDraftJobStatus,
    promoteTaxonomy,
    getPromoteJobStatus,
    publishTaxonomy,
    getPublishJobStatus_1,
    unpublishTaxonomy,
    getUnpublishJobStatus_1
  }
}
/** Tokens */
const tokens_ = (host, authorization) => {
  /**  @function getCSRFToken - Read a CSRF Token.
   */
  const getCSRFToken = () => {
    const qs = ''
    const path = '/content/management/api/v1.1/token' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return { getCSRFToken }
}
/** Types */
const types_ = (host, authorization) => {
  /**  @function listDataTypes - List All Data Types.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const listDataTypes = ({ links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/dataTypes' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listTypes - List All Types.
   * @param {string} roleName - This parameter is used to filter the returned types with the given role name. This parameter is optional in the query and by default all the types are returned..
   * @param {string} q - This parameter accepts a query expression condition that matches the field values. The value of query condition follows the format of <i><b>{fieldName} {operator} "{fieldValue}"</b></i>. The only fieldNames allowed for now are <i><b>roleName</b></i>, <i><b>repositoryId</b></i> and <i><b>name</b></i> and only allowed operators for now are <i><b>co</b></i> on <i><b>name</b></i> and <i><b>eq</b></i> on the others. This query param is optional and defaults to <i><b>roleName eq "viewer"</b></i> which filters the resources with at least given role. <i><b>name</b></i> is interpreted in the context of the resource being requested. For eg. name for content types implies content type name.<br><b>Example</b>:<br> ?q=roleName eq "manager").
   * @param {boolean} isRoleByShare - This parameter is used to filter the returned results explicitly shared to the user. This parameter is optional in the query and by default it is set to false..
   * @param {string} fields - This parameter is used to control the returned fields in each type in the list. All the field names are case-sensitive. Each type has both standard fields (<i>id</i>, <i>name</i>, <i>description</i>, <i>createdBy</i>, <i>createdDate</i>, <i>updatedBy</i>, <i>updatedDate</i>, <i>roleName</i>, <i>allowedActions</i>) and additional fields (<i>fields</i>, <i>properties</i>, <i>connectorInfos</i>). When <i>fields</i> is specified as <i>all</i> (case-insensitive), all the standard and additional fields are returned. The standard fields are always returned in the response and cannot be filtered out. The user can filter out only the additional fields. This parameter is optional in the query, and by default the result shows all standard and additional fields in the response. Any incorrect or invalid field name given in the query will throw an error. <br><br> <b>Example</b>: <i>?fields=fields,connectorInfos</i> <br> This returns all standard fields along with the <i>fields</i> and <i>connectorInfos</i> additional fields for each type.<br> <b>Example</b>: <i>?fields=all</i> <br> This will return all standard fields and all additional fields for each type. <br> .
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {string} orderBy - This parameter is used to control the order of results. The value of this query parameter follows the format of <i> fieldName:[asc/desc]</i>. <i>asc</i> stands for ascending order  <i>desc</i> stands for descending order, default order is <i>asc</i>.The only fields allowed in the field name are <b>name</b> and <b>updatedDate</b>..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   */
  const listTypes = ({
    roleName,
    q,
    isRoleByShare,
    fields,
    links,
    offset,
    limit,
    orderBy,
    totalResults
  }) => {
    const queryParams = {
      roleName: roleName,
      q: q,
      isRoleByShare: isRoleByShare,
      fields: fields,
      links: links,
      offset: offset,
      limit: limit,
      orderBy: orderBy,
      totalResults: totalResults
    }
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/types' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function createType - Create a Type.
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {undefined} body - Creates a type with the given information in the payload. The fields <i>id, createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i>  will be ignored even if given in the payload..
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const createType = ({ links, body, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path = '/content/management/api/v1.1/types' + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'POST', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function getType - Read a Type.
   * @param {string} name - Type name identifier..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   */
  const getType = ({ name, links }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/types/{name}'.replace('{name}', name) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function updateType - Update a Type.
   * @param {string} name - Type name identifier..
   * @param {undefined} body - Updates a type with the given information in the payload. The fields <i>createdBy, createdDate, updatedBy, updatedDate</i> and <i>links</i>  will be ignored even if given in the payload..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const updateType = ({ name, body, links, xRequestedWith }) => {
    const queryParams = { links: links }
    // consumes application/json
    const data = typeof body === 'string' ? body : JSON.stringify(body)
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/types/{name}'.replace('{name}', name) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'PUT', headers, agent, body: data }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function deleteType - Delete a Type.
   * @param {string} name - Type name identifier..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>.
   * @param {string} xRequestedWith - A custom header to mitigate CSRF attacks..
   */
  const deleteType = ({ name, links, xRequestedWith }) => {
    const queryParams = { links: links }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/types/{name}'.replace('{name}', name) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json',
      'X-Requested-With': xRequestedWith
    }
    const options = { method: 'DELETE', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  /**  @function listTypePermissions - List All Permissions on a Type.
   * @param {string} name - Type name identifier..
   * @param {integer} offset - This parameter accepts a non negative integer and is used to control the start index of the result..
   * @param {integer} limit - This parameter accepts a non negative integer and is used to control the size of the result..
   * @param {boolean} totalResults - This parameter accepts a boolean flag. If specified as <b>true</b>, then the returned result must include the total result count..
   * @param {string} links - This parameter accepts a comma-separated list of link names. By default, this parameter gives all the links applicable. Possible values are: <i>self</i>, <i>canonical</i>, <i>describedby</i>, <i>first</i>, <i>last</i>, <i>prev</i>, <i>next</i>.
   */
  const listTypePermissions = ({
    name,
    offset,
    limit,
    totalResults,
    links
  }) => {
    const queryParams = {
      offset: offset,
      limit: limit,
      totalResults: totalResults,
      links: links
    }
    const qs = toQS(queryParams)
    const path =
      '/content/management/api/v1.1/types/{name}/permissions'.replace(
        '{name}',
        name
      ) + qs
    const headers = {
      Authorization: authorization,
      'Content-Type': 'application/json'
    }
    const options = { method: 'GET', headers, agent }
    debug('%s%s %j', host, path, { method: options.method, headers })
    return fetch(host + path, options)
  }
  return {
    listDataTypes,
    listTypes,
    createType,
    getType,
    updateType,
    deleteType,
    listTypePermissions
  }
}
module.exports.channelSecret = channelSecret_
module.exports.channels = channels_
module.exports.collections = collections_
module.exports.connectors = connectors_
module.exports.digitalItemRenditions = digitalItemRenditions_
module.exports.itemRevisions = itemRevisions_
module.exports.itemVariations = itemVariations_
module.exports.items = items_
module.exports.itemsBulkOperations = itemsBulkOperations_
module.exports.itemsSearch = itemsSearch_
module.exports.itemsBySlug = itemsBySlug_
module.exports.languages = languages_
module.exports.localizationPolicies = localizationPolicies_
module.exports.oAuthTokens = oAuthTokens_
module.exports.permissionOperations = permissionOperations_
module.exports.recommendations = recommendations_
module.exports.repositories = repositories_
module.exports.taxonomies = taxonomies_
module.exports.tokens = tokens_
module.exports.types = types_
const client = (host, authorization) => {
  return {
    channelSecret: channelSecret_(host, authorization),
    channels: channels_(host, authorization),
    collections: collections_(host, authorization),
    connectors: connectors_(host, authorization),
    digitalItemRenditions: digitalItemRenditions_(host, authorization),
    itemRevisions: itemRevisions_(host, authorization),
    itemVariations: itemVariations_(host, authorization),
    items: items_(host, authorization),
    itemsBulkOperations: itemsBulkOperations_(host, authorization),
    itemsSearch: itemsSearch_(host, authorization),
    itemsBySlug: itemsBySlug_(host, authorization),
    languages: languages_(host, authorization),
    localizationPolicies: localizationPolicies_(host, authorization),
    oAuthTokens: oAuthTokens_(host, authorization),
    permissionOperations: permissionOperations_(host, authorization),
    recommendations: recommendations_(host, authorization),
    repositories: repositories_(host, authorization),
    taxonomies: taxonomies_(host, authorization),
    tokens: tokens_(host, authorization),
    types: types_(host, authorization)
  }
}
module.exports.readConfig = require('./cli-util').readConfig
module.exports.client = client
